# 七合一 SystemUI 聚合 QS（0.2 重构候选）

- 包名：`com.dafeiyu.seveninone`
- 标准 `TileService` 只负责让系统发现并添加“七合一”；它不打开应用、不承载二级页。
- SystemUI hook 将该 tile 固定为真实 2×2，并在其 ViewOverlay 内绘制参考图的七项聚合布局。
- 子项点击通过 SystemUI 进程内已经存在的原生 QSTile 对象执行；应用不执行 Root 命令，也不模拟系统开关。
- 点击聚合磁贴空白区域后，SystemUI 内加入二级覆盖页；关闭/返回同样不离开 SystemUI。
- 应用主页仅用于选择 7 项及顺序，并通过 Provider 写入 SystemUI 读取的展示配置。

## 参考图布局

当前默认顺序为：飞行模式、一加互传、WLAN、移动数据、蓝牙、个人热点、定位服务。
前两项是顶部圆形控制，第三项是左下大圆，后四项是右侧 2×2 小圆；二级页按飞行模式、WLAN、一加互传、移动数据、蓝牙、定位服务、个人热点的宽卡/方卡布局排列。
应用可替换 12 个候选项中的 7 个并调整顺序，顺序对应上述七个槽位。

## 当前边界

- 这是静态重构候选，尚未安装、启用 LSPosed、重启 SystemUI 或做真机视觉验证。
- 若 ROM 的原生 tile spec 与候选别名不同，SystemUI hook 会记录“native tile not found”，不通过应用命令兜底。
- 历史源码、APK 与本轮重构前源树保留在 `backups/pre-systemui-refactor-20261028-1604/` 及 `legacy-pre-refactor-20261028-1604/`。
