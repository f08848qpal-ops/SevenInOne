package org.json;
public class JSONObject {
  public JSONObject() {}
  public JSONObject(String value) throws JSONException {}
  public JSONObject put(String key, Object value) throws JSONException { return this; }
  public int optInt(String key, int fallback) { return fallback; }
  public String optString(String key, String fallback) { return fallback; }
  public JSONArray optJSONArray(String key) { return null; }
  @Override public String toString() { return "{}"; }
}
