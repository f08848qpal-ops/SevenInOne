package org.json;
public class JSONArray {
  public JSONArray() {}
  public JSONArray(String value) throws JSONException {}
  public int length() { return 0; }
  public JSONObject optJSONObject(int index) { return null; }
  public String optString(int index, String fallback) { return fallback; }
  public JSONArray put(Object value) { return this; }
  @Override public String toString() { return "[]"; }
}
