package android.icu.text;
import java.util.Locale;
public abstract class BreakIterator {
  public static BreakIterator getCharacterInstance(Locale locale) { return new BreakIterator() {
    private String text = "";
    public void setText(String value) { text = value == null ? "" : value; }
    public int first() { return 0; }
    public int next() { return text.length(); }
  }; }
  public abstract void setText(String value);
  public abstract int first();
  public abstract int next();
}
