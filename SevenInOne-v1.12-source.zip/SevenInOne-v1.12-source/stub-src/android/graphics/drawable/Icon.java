package android.graphics.drawable;
import android.content.Context;
public class Icon {
    public static Icon createWithResource(Context context, int resourceId) { return null; }
}
