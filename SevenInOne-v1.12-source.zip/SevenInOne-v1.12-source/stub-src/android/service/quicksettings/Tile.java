package android.service.quicksettings;
import android.graphics.drawable.Icon;
public class Tile {
  public static final int STATE_UNAVAILABLE=0, STATE_INACTIVE=1, STATE_ACTIVE=2;
  public void setState(int state) {}
  public int getState() { return STATE_INACTIVE; }
  public void setLabel(CharSequence label) {}
  public void setSubtitle(CharSequence subtitle) {}
  public void setContentDescription(CharSequence description) {}
  public void setIcon(Icon icon) {}
  public void updateTile() {}
}
