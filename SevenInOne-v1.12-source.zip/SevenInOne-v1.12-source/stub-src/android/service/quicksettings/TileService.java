package android.service.quicksettings;
import android.app.Service;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.os.IBinder;
import java.util.concurrent.Executor;
import java.util.function.Consumer;
public abstract class TileService extends Service {
  public static final int TILE_ADD_REQUEST_RESULT_TILE_ADDED=0;
  public static final int TILE_ADD_REQUEST_RESULT_TILE_ALREADY_ADDED=1;
  public static final int TILE_ADD_REQUEST_RESULT_TILE_NOT_ADDED=2;
  public void onTileAdded() {}
  public void onTileRemoved() {}
  public void onStartListening() {}
  public void onStopListening() {}
  public void onClick() {}
  public Tile getQsTile() { return null; }
  public void updateTile() {}
  public void startActivityAndCollapse(PendingIntent pendingIntent) {}
  public static void requestListeningState(Context context, ComponentName component) {}
  public static void requestAddTileService(Context context, ComponentName component, CharSequence label, Icon icon, Executor executor, Consumer<Integer> callback) {}
  @Override public IBinder onBind(Intent intent) { return null; }
}
