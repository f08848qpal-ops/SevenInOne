package io.github.libxposed.api;
import android.content.pm.ApplicationInfo;
public interface XposedModuleInterface {
  class ModuleLoadedParam {
    public String getProcessName() { return ""; }
    public boolean isSystemServer() { return false; }
  }
  class PackageReadyParam {
    public String getPackageName() { return ""; }
    public ClassLoader getClassLoader() { return null; }
    public ApplicationInfo getApplicationInfo() { return null; }
    public boolean isFirstPackage() { return false; }
  }
  class SystemServerStartingParam {
    public ClassLoader getClassLoader() { return null; }
  }
  class HotReloadingParam {}
}
