package io.github.libxposed.api;
import java.lang.reflect.Executable;
import java.lang.reflect.Method;
import java.util.List;
public interface XposedInterface {
  int getApiVersion();
  HookBuilder hook(Executable executable);
  Invoker getInvoker(Executable executable);
  boolean deoptimize(Executable executable);
  void log(int priority, String tag, String message);
  void log(int priority, String tag, String message, Throwable throwable);
  enum ExceptionMode { PASSTHROUGH, IGNORE }
  interface Hooker { Object intercept(Chain chain) throws Throwable; }
  interface Chain {
    Executable getExecutable(); Object getThisObject(); List<Object> getArgs();
    Object proceed(Object[] args) throws Throwable;
    Object proceedWith(Object thisObject, Object[] args) throws Throwable;
  }
  interface HookBuilder {
    HookBuilder setPriority(int priority); HookBuilder setId(String id);
    HookBuilder setExceptionMode(ExceptionMode mode); HookHandle intercept(Hooker hooker);
  }
  interface HookHandle { void unhook(); HookHandle replaceHook(Hooker hooker); }
  interface Invoker {
    enum Type { ORIGIN }
    Invoker setType(Type type); Object invoke(Object thisObject, Object[] args) throws Throwable;
    Object invokeSpecial(Object thisObject, Object[] args) throws Throwable;
  }
}
