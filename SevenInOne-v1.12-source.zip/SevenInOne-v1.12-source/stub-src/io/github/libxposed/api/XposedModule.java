package io.github.libxposed.api;
import java.lang.reflect.Executable;
public abstract class XposedModule implements XposedInterface, XposedModuleInterface {
  public void onModuleLoaded(XposedModuleInterface.ModuleLoadedParam param) {}
  public void onPackageReady(XposedModuleInterface.PackageReadyParam param) {}
  public void onSystemServerStarting(XposedModuleInterface.SystemServerStartingParam param) {}
  public boolean onHotReloading(XposedModuleInterface.HotReloadingParam param) { return false; }
  public String getFrameworkName() { return "LSPosed"; }
  public int getFrameworkVersion() { return 102; }
  public int getApiVersion() { return 102; }
  public HookBuilder hook(Executable executable) { return null; }
  public Invoker getInvoker(Executable executable) { return null; }
  public boolean deoptimize(Executable executable) { return false; }
  public void log(int priority, String tag, String message) {}
  public void log(int priority, String tag, String message, Throwable throwable) {}
}
