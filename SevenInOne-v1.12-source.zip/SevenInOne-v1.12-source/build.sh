#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
TOOLS=/data/local/tmp/lgtools
ANDROID_JAR="$TOOLS/android-35.jar"
XPOSED_JAR="$TOOLS/xposed-api-82.jar"
R8_JAR="$TOOLS/r8.jar"
FRAMEWORK_RES=/system/framework/framework-res.apk
KEY_DIR="$ROOT/keys"
KEYSTORE="$KEY_DIR/seveninone-dev.keystore"
ALIAS=seveninone
STAMP=$(date +%Y%m%d-%H%M%S)
BUILD="$ROOT/build/v1-$STAMP"
APK="$ROOT/dist/SevenInOne-OplusX-Port-v1.12-$STAMP.apk"

for f in "$ANDROID_JAR" "$XPOSED_JAR" "$R8_JAR" "$FRAMEWORK_RES"; do
    [ -f "$f" ] || { echo "missing build dependency: $f" >&2; exit 2; }
done
for tool in aapt2 javac java jar keytool apksigner 7zz taskset; do
    command -v "$tool" >/dev/null || { echo "missing tool: $tool" >&2; exit 2; }
done
mkdir -p "$BUILD/classes" "$BUILD/stub-classes" "$BUILD/dex" "$BUILD/gen" "$KEY_DIR" "$ROOT/dist"

ONLINE=$(cat /sys/devices/system/cpu/online)
read_cpu_list() {
    local token start end c
    local -a tokens
    IFS=',' read -ra tokens <<< "$ONLINE"
    for token in "${tokens[@]}"; do
        if [[ "$token" == *-* ]]; then
            start=${token%-*}; end=${token#*-}
            for ((c=start; c<=end; c++)); do echo "$c"; done
        else echo "$token"; fi
    done
}
mapfile -t ONLINE_CPUS < <(read_cpu_list)
[ "${#ONLINE_CPUS[@]}" -ge 3 ] || { echo "too few online CPUs: $ONLINE" >&2; exit 2; }
LOW_CORE=; LOW_CAP=2147483647; HIGH_CORE=; HIGH_CAP=-1
for c in "${ONLINE_CPUS[@]}"; do
    cap=$(cat "/sys/devices/system/cpu/cpu${c}/cpu_capacity" 2>/dev/null || echo 0)
    if [ "$cap" -lt "$LOW_CAP" ]; then LOW_CORE=$c; LOW_CAP=$cap; fi
    if [ "$cap" -ge "$HIGH_CAP" ]; then HIGH_CORE=$c; HIGH_CAP=$cap; fi
done
[ -n "$LOW_CORE" ] && [ -n "$HIGH_CORE" ] && [ "$LOW_CORE" != "$HIGH_CORE" ] || { echo "cannot reserve distinct low/high CPUs" >&2; exit 2; }
BUILD_CPUS=
for c in "${ONLINE_CPUS[@]}"; do
    if [ "$c" != "$LOW_CORE" ] && [ "$c" != "$HIGH_CORE" ]; then BUILD_CPUS="${BUILD_CPUS:+$BUILD_CPUS,}$c"; fi
done
[ -n "$BUILD_CPUS" ] || { echo "no build CPUs remain" >&2; exit 2; }
printf 'CPU online=%s reserved_low=%s(cap=%s) reserved_high=%s(cap=%s) build_cpus=%s\n' "$ONLINE" "$LOW_CORE" "$LOW_CAP" "$HIGH_CORE" "$HIGH_CAP" "$BUILD_CPUS" | tee "$BUILD/cpu-affinity.log"

AFFINITY_LOG="$BUILD/cpu-affinity.log"
export AFFINITY_LOG
run_affined() {
    taskset -c "$BUILD_CPUS" bash -c '
        set -euo pipefail
        expected=$(awk "/Cpus_allowed_list/ {print \$2}" "/proc/$$/status")
        expand_cpu_list() {
            local token start end c
            IFS="," read -ra tokens <<< "$1"
            for token in "${tokens[@]}"; do
                if [[ "$token" == *-* ]]; then
                    start=${token%-*}; end=${token#*-}
                    for ((c=start; c<=end; c++)); do echo "$c"; done
                elif [ -n "$token" ]; then echo "$token"; fi
            done | sort -n | tr "\n" ","
        }
        "$@" & child=$!
        checked=0
        for i in $(seq 1 80); do
            if [ -r "/proc/$child/status" ]; then
                actual=$(awk "/Cpus_allowed_list/ {print \$2}" "/proc/$child/status")
                if [ -n "$actual" ]; then
                    printf "AFFINITY pid=%s expected=%s actual=%s command=%s\n" "$child" "$expected" "$actual" "$1" | tee -a "$AFFINITY_LOG"
                    exp_set=$(expand_cpu_list "$expected")
                    act_set=$(expand_cpu_list "$actual")
                    [ "$act_set" = "$exp_set" ] || { echo "affinity mismatch: expected set=$exp_set actual set=$act_set" >&2; kill "$child" 2>/dev/null || true; exit 3; }
                    checked=1
                    break
                fi
            fi
            sleep 0.025
        done
        [ "$checked" = 1 ] || { echo "could not verify child affinity" >&2; kill "$child" 2>/dev/null || true; exit 3; }
        wait "$child"
    ' run_affined "$@"
}

if [ ! -f "$KEYSTORE" ]; then
    run_affined keytool -genkeypair -keystore "$KEYSTORE" -storepass android -keypass android \
        -alias "$ALIAS" -keyalg RSA -keysize 2048 -validity 10000 \
        -dname 'CN=SevenInOne Local Development,O=Dafeiyu,C=CN' >/dev/null 2>&1
fi

printf '\n== resources ==\n'
run_affined aapt2 compile --dir "$ROOT/resources/res" -o "$BUILD/resources.zip"
run_affined aapt2 link -o "$BUILD/resources.apk" --manifest "$ROOT/AndroidManifest.xml" \
    -I "$FRAMEWORK_RES" -A "$ROOT/assets" --java "$BUILD/gen" \
    --min-sdk-version 33 --target-sdk-version 36 "$BUILD/resources.zip"

printf '\n== TileService compile stubs (never packaged) ==\n'
find "$ROOT/stub-src" -type f -name '*.java' | sort > "$BUILD/stub-sources.list"
run_affined javac --release 8 -encoding UTF-8 -Xlint:-options \
    -cp "$ANDROID_JAR" -d "$BUILD/stub-classes" @"$BUILD/stub-sources.list"
run_affined jar cf "$BUILD/compile-stubs.jar" -C "$BUILD/stub-classes" .

printf '\n== app and Xposed Java ==\n'
find "$ROOT/src" "$BUILD/gen" -type f -name '*.java' | sort > "$BUILD/sources.list"
run_affined javac --release 8 -encoding UTF-8 -Xlint:-options \
    -cp "$ANDROID_JAR:$XPOSED_JAR:$BUILD/compile-stubs.jar" \
    -d "$BUILD/classes" @"$BUILD/sources.list"
run_affined jar cf "$BUILD/app-classes.jar" -C "$BUILD/classes" .

printf '\n== dex ==\n'
run_affined java -cp "$R8_JAR" com.android.tools.r8.D8 --min-api 33 \
    --lib "$ANDROID_JAR" --classpath "$XPOSED_JAR" --classpath "$BUILD/compile-stubs.jar" \
    --output "$BUILD/dex" "$BUILD/app-classes.jar"

printf '\n== package ==\n'
cp "$BUILD/resources.apk" "$BUILD/unsigned.apk"
(cd "$BUILD/dex" && 7zz a -tzip "$BUILD/unsigned.apk" classes.dex >/dev/null)

printf '\n== sign ==\n'
apksigner sign --ks "$KEYSTORE" --ks-key-alias "$ALIAS" \
    --ks-pass pass:android --key-pass pass:android \
    --min-sdk-version 33 --v1-signing-enabled false --v2-signing-enabled true \
    --v3-signing-enabled true --v4-signing-enabled false --out "$APK" "$BUILD/unsigned.apk"

printf '\n== static verification ==\n'
7zz t "$APK" | tail -n 3
aapt2 dump badging "$APK" > "$BUILD/badging.txt"
grep -E "^package:|^application-label|^launchable-activity" "$BUILD/badging.txt" | head -n 6
apksigner verify --verbose "$APK" > "$BUILD/signature.txt"
sed -n '1,5p' "$BUILD/signature.txt"
unzip -l "$APK" | grep -E 'assets/xposed_init|classes.dex'
if ! unzip -Z1 "$APK" | grep -Fx 'assets/xposed_init' >/dev/null; then echo 'ERROR: legacy xposed_init missing' >&2; exit 4; fi
if unzip -l "$APK" | grep -q 'android/service/quicksettings/'; then echo 'ERROR: compile stubs were packaged' >&2; exit 4; fi
unzip -p "$APK" assets/xposed_init | grep -Fx 'com.dafeiyu.seveninone.hook.SevenInOneHook'
sha256sum "$APK" | tee "$BUILD/sha256.txt"
printf '\nBUILD OK\nAPK=%s\n' "$APK"
