# SevenInOne v1.12 source subset

This archive contains the public source subset for the v1.12 MIUIx UI rebuild:

- `src/` — application, provider and SystemUI/LSPosed hook source
- `resources/` — resources including the author avatar
- `stub-src/` — compile-only Android/SystemUI stubs
- `assets/` — Xposed entry metadata

Intentionally excluded:

- `keys/` — signing keystore
- `build/`, `dist/` — generated build output
- `backups/`, `port-notes/`, temporary work trees — development history and diagnostics
- local machine paths, device logs and private configuration

The included `build.sh` expects the Android/SystemUI build dependencies described in the project setup; it generates a local development signature when no keystore exists.
