package com.dafeiyu.seveninone;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/** Configuration-only bridge. It never toggles a tile and never opens a page. */
public final class SevenProvider extends ContentProvider {
    public static final String AUTHORITY = "com.dafeiyu.seveninone.provider";
    public static final Uri URI = Uri.parse("content://" + AUTHORITY + "/control");
    /** Same logical service format as OplusX, but with our own component. */
    public static final String TILE_CLASS = "";
    public static final String TILE_SPEC = "dafeiyu_combo_2x2";
    private static final String PREFS = "seveninone";
    /** Tile specs reported by the SystemUI hook: every tile this device can add. */
    private static final String CATALOG = "catalog";
    private static final Set<String> CALLERS = new HashSet<>(Arrays.asList(
        "com.android.systemui", "com.dafeiyu.seveninone"));

    private static final String CONFIG_UPDATED = "com.dafeiyu.seveninone.CONFIG_UPDATED";

    @Override public boolean onCreate() {
        try { pushConfig(getContext()); } catch (Throwable ignored) { }
        return true;
    }

    public static void pushConfig(Context context) {
        if (context == null) return;
        String[] values = selected(context);
        android.content.Intent intent = new android.content.Intent(CONFIG_UPDATED);
        intent.setPackage("com.android.systemui");
        intent.putExtra("selected", values);
        context.sendBroadcast(intent);
    }
    @Override public Cursor query(Uri uri, String[] p, String s, String[] a, String o) { return null; }
    @Override public String getType(Uri uri) { return "vnd.android.cursor.item/vnd.dafeiyu.seveninone.config"; }
    @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException(); }
    @Override public int delete(Uri uri, String s, String[] a) { throw new UnsupportedOperationException(); }
    @Override public int update(Uri uri, ContentValues v, String s, String[] a) { throw new UnsupportedOperationException(); }

    private boolean authorized() {
        Context c = getContext();
        if (c == null) return false;
        int uid = Binder.getCallingUid();
        if (uid == android.os.Process.myUid()) return true;
        String[] packages = c.getPackageManager().getPackagesForUid(uid);
        if (packages == null) return false;
        for (String pkg : packages) if (CALLERS.contains(pkg)) return true;
        return false;
    }

    public static String[] selected(Context context) {
        String joined = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString("selected", join(TileCatalog.DEFAULT));
        String[] raw = joined.split(",", -1);
        ArrayList<String> valid = new ArrayList<>();
        for (String id : raw) {
            if (isValidSpec(id) && !valid.contains(id)) valid.add(id);
        }
        if (valid.size() < 3 || valid.size() > 7) return TileCatalog.DEFAULT.clone();
        return valid.toArray(new String[0]);
    }

    public static String[] availableTiles(Context context) {
        String joined = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(CATALOG, "");
        if (joined == null || joined.isEmpty()) return new String[0];
        ArrayList<String> out = new ArrayList<>();
        for (String id : joined.split(",", -1)) {
            if (isValidSpec(id) && !out.contains(id)) out.add(id);
        }
        return out.toArray(new String[0]);
    }

    public static boolean isValidSpec(String spec) {
        if (spec == null || spec.length() == 0 || spec.length() > 512) return false;
        if (spec.startsWith("oplusx_combo_") || spec.startsWith("com.dafeiyu.seveninone")) return false;
        return spec.matches("[A-Za-z0-9_.:-]+")
            || spec.matches("custom\\([A-Za-z0-9_.$]+/[A-Za-z0-9_.$]+\\)");
    }

    private static String join(String[] values) {
        StringBuilder b = new StringBuilder();
        for (String v : values) { if (b.length() > 0) b.append(','); b.append(v); }
        return b.toString();
    }
    private static Bundle error(String message) {
        Bundle b = new Bundle(); b.putBoolean("ok", false); b.putString("message", message); return b;
    }

    @Override public Bundle call(String method, String arg, Bundle extras) {
        if (!authorized()) return error("拒绝的调用方");
        Context c = getContext();
        if (c == null) return error("provider unavailable");
        if ("config".equals(method)) {
            String[] values = selected(c);
            Bundle b = new Bundle();
            b.putStringArray("selected", values);
            b.putInt("count", values.length);
            b.putString("tile_spec", TILE_SPEC);
            b.putBoolean("enabled", true);
            b.putBoolean("show_labels", false);
            b.putBoolean("long_press_expand", true);
            b.putInt("config_version", 3);
            return b;
        }
        if ("report_tiles".equals(method)) {
            String[] values = extras == null ? null : extras.getStringArray("specs");
            if (values == null) return error("no specs");
            ArrayList<String> out = new ArrayList<>();
            for (String value : values) {
                if (out.size() >= 400) break;
                if (isValidSpec(value) && !out.contains(value)) out.add(value);
            }
            boolean ok = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(CATALOG, join(out.toArray(new String[0]))).commit();
            Bundle result = new Bundle(); result.putBoolean("ok", ok); return result;
        }
        if ("request_catalog".equals(method)) {
            try {
                c.sendBroadcast(new android.content.Intent("com.dafeiyu.seveninone.REQUEST_CATALOG"));
            } catch (Throwable ignored) { }
            Bundle result = new Bundle(); result.putBoolean("ok", true); return result;
        }
        if ("available_tiles".equals(method)) {
            Bundle result = new Bundle();
            result.putStringArray("specs", availableTiles(c));
            return result;
        }
        if ("save_config".equals(method) || "save_systemui_config".equals(method)) {
            if (Binder.getCallingUid() != android.os.Process.myUid()) return error("仅本模块设置页可写入展示配置");
            String[] values = extras == null ? null : extras.getStringArray("selected");
            if (values == null || values.length < 3 || values.length > 7) return error("必须选择 3 到 7 项");
            HashSet<String> unique = new HashSet<>();
            for (String value : values) {
                if (!isValidSpec(value) || !unique.add(value)) return error("项目无效或重复");
            }
            boolean committed = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("selected", join(values)).commit();
            if (!committed) return error("配置写入失败");
            try { c.getContentResolver().notifyChange(URI, null); } catch (Throwable ignored) { }
            try { pushConfig(c); } catch (Throwable ignored) { }
            Bundle result = new Bundle(); result.putBoolean("ok", true); return result;
        }
        return error("unknown method");
    }
}
