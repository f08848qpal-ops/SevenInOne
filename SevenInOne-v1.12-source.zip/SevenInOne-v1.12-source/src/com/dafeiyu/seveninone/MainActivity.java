package com.dafeiyu.seveninone;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * MIUIx-style two-page settings surface. SystemUI still owns the real tile;
 * this activity only edits the seven slots and displays the project page.
 */
public final class MainActivity extends Activity {
    private static final int BG = Color.rgb(246, 247, 249);
    private static final int CARD = Color.WHITE;
    private static final int TEXT = Color.rgb(31, 35, 41);
    private static final int MUTED = Color.rgb(125, 133, 145);
    private static final int ACCENT = Color.rgb(55, 126, 245);
    private static final int SOFT = Color.rgb(235, 241, 252);

    private final ArrayList<String> selected = new ArrayList<>();
    private final ArrayList<String> catalog = new ArrayList<>();
    private final java.util.LinkedHashMap<String, String> labels = new java.util.LinkedHashMap<>();
    private FrameLayout pageHost;
    private TextView navHome;
    private TextView navConfig;
    private PreviewLayout preview;
    private TextView configStatus;
    private int pageIndex;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        configureWindow();
        selected.addAll(Arrays.asList(SevenProvider.selected(this)));
        try { SevenProvider.pushConfig(this); } catch (Throwable ignored) { }
        mergeCatalog();
        ensureSevenSlots();
        buildShell();
    }

    private void configureWindow() {
        try {
            Object window = getWindow();
            window.getClass().getMethod("setStatusBarColor", Integer.TYPE).invoke(window, BG);
            window.getClass().getMethod("setNavigationBarColor", Integer.TYPE).invoke(window, BG);
            View decor = getWindow().getDecorView();
            // SYSTEM_UI_FLAG_LIGHT_STATUS_BAR = 0x2000;
            // SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR = 0x10.
            decor.setSystemUiVisibility(0x2000 | 0x10);
        } catch (Throwable ignored) { }
    }

    private void mergeCatalog() {
        catalog.clear();
        catalog.addAll(Arrays.asList(TileCatalog.IDS));
        for (String spec : SevenProvider.availableTiles(this)) if (!catalog.contains(spec)) catalog.add(spec);
        readGlobalCatalog();
        for (String spec : selected) if (!catalog.contains(spec)) catalog.add(spec);
    }

    private void ensureSevenSlots() {
        for (String spec : TileCatalog.DEFAULT) {
            if (selected.size() >= 7) break;
            if (!selected.contains(spec)) selected.add(spec);
        }
        for (String spec : catalog) {
            if (selected.size() >= 7) break;
            if (!selected.contains(spec)) selected.add(spec);
        }
    }

    private void buildShell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        pageHost = new FrameLayout(this);
        root.addView(pageHost, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout nav = new LinearLayout(this);
        nav.setPadding(dp(14), dp(8), dp(14), dp(10));
        nav.setGravity(Gravity.CENTER);
        nav.setBackgroundColor(BG);
        navHome = navItem("主页");
        navConfig = navItem("配置");
        nav.addView(navHome, new LinearLayout.LayoutParams(0, dp(48), 1f));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        cp.leftMargin = dp(8);
        nav.addView(navConfig, cp);
        navHome.setOnClickListener(v -> showPage(0));
        navConfig.setOnClickListener(v -> showPage(1));
        root.addView(nav, new LinearLayout.LayoutParams(-1, dp(70)));
        setContentView(root);
        showPage(0);
    }

    private TextView navItem(String label) {
        TextView v = text(label, 15, MUTED, true);
        v.setGravity(Gravity.CENTER);
        return v;
    }

    private void showPage(int index) {
        pageIndex = index;
        pageHost.removeAllViews();
        pageHost.addView(index == 0 ? buildHomePage() : buildConfigPage(),
            new FrameLayout.LayoutParams(-1, -1));
        navHome.setBackground(rounded(index == 0 ? CARD : BG, 22));
        navConfig.setBackground(rounded(index == 1 ? CARD : BG, 22));
        navHome.setTextColor(index == 0 ? TEXT : MUTED);
        navConfig.setTextColor(index == 1 ? TEXT : MUTED);
    }

    private View buildHomePage() {
        ScrollView scroll = new ScrollView(this);
        scroll.setClipToPadding(false);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), statusBarHeight() + dp(18), dp(20), dp(24));
        page.setBackgroundColor(BG);

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("七合一", 28, TEXT, true);
        toolbar.addView(title, new LinearLayout.LayoutParams(0, dp(52), 1f));
        TextView badge = text("MIUIx", 12, ACCENT, true);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(dp(13), 0, dp(13), 0);
        badge.setBackground(rounded(SOFT, 20));
        toolbar.addView(badge, new LinearLayout.LayoutParams(-2, dp(34)));
        page.addView(toolbar);
        page.addView(text("系统磁贴组合工具", 14, MUTED, false), params(-1, -2));

        LinearLayout profile = card();
        profile.setGravity(Gravity.CENTER_VERTICAL);
        profile.setPadding(dp(18), dp(18), dp(18), dp(18));
        AvatarView avatar = new AvatarView(this);
        avatar.setImageResource(com.dafeiyu.seveninone.R.drawable.avatar);
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        avatar.setBackground(oval(CARD, 0xFFE0E6F0));
        profile.addView(avatar, new LinearLayout.LayoutParams(dp(82), dp(82)));
        LinearLayout profileText = new LinearLayout(this);
        profileText.setOrientation(LinearLayout.VERTICAL);
        profileText.setPadding(dp(16), 0, 0, 0);
        profileText.addView(text("我真的不姓峰_", 21, TEXT, true), params(-1, -2));
        profileText.addView(text("SevenInOne · 七合一控制中心", 13, MUTED, false), params(-1, -2));
        TextView open = text("打开配置  ›", 14, ACCENT, true);
        open.setPadding(0, dp(10), 0, 0);
        open.setOnClickListener(v -> showPage(1));
        profileText.addView(open, params(-1, -2));
        profile.addView(profileText, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams pp = params(-1, -2); pp.topMargin = dp(22); page.addView(profile, pp);

        LinearLayout about = card();
        about.setOrientation(LinearLayout.VERTICAL);
        about.setPadding(dp(18), dp(18), dp(18), dp(18));
        about.addView(text("关于这个模块", 18, TEXT, true), params(-1, -2));
        TextView statement = text(
            "本模块免费、开源，仅供学习与个人使用。\n\n" +
            "禁止未经授权搬运、冒名发布、售卖，或借此模块圈钱。\n\n" +
            "作者：我真的不姓峰_",
            14, MUTED, false);
        statement.setLineSpacing(dp(3), 1f);
        LinearLayout.LayoutParams st = params(-1, -2); st.topMargin = dp(10); about.addView(statement, st);
        LinearLayout.LayoutParams ap = params(-1, -2); ap.topMargin = dp(14); page.addView(about, ap);

        LinearLayout info = card();
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(18), dp(16), dp(18), dp(16));
        info.addView(text("当前状态", 17, TEXT, true), params(-1, -2));
        info.addView(text("已配置 " + selected.size() + " 项 · 检测到 " + catalog.size() + " 项可适配磁贴",
            14, MUTED, false), topParams(-1, -2, 7));
        Button config = primaryButton("进入配置");
        config.setOnClickListener(v -> showPage(1));
        info.addView(config, topParams(-1, dp(46), 14));
        page.addView(info, topParams(-1, -2, 14));

        scroll.addView(page);
        return scroll;
    }

    private View buildConfigPage() {
        ScrollView scroll = new ScrollView(this);
        scroll.setClipToPadding(false);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), statusBarHeight() + dp(10), dp(18), dp(24));
        page.setBackgroundColor(BG);

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = text("‹", 37, TEXT, false);
        back.setGravity(Gravity.CENTER);
        back.setBackground(rounded(CARD, 22));
        back.setOnClickListener(v -> showPage(0));
        toolbar.addView(back, new LinearLayout.LayoutParams(dp(46), dp(46)));
        LinearLayout toolbarTitle = new LinearLayout(this);
        toolbarTitle.setOrientation(LinearLayout.VERTICAL);
        toolbarTitle.setPadding(dp(13), 0, 0, 0);
        toolbarTitle.addView(text("配置七合一", 22, TEXT, true), params(-1, -2));
        toolbarTitle.addView(text("点击圆盘选择系统磁贴", 12, MUTED, false), params(-1, -2));
        toolbar.addView(toolbarTitle, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView refresh = text("刷新", 13, ACCENT, true);
        refresh.setGravity(Gravity.CENTER);
        refresh.setBackground(rounded(SOFT, 20));
        refresh.setOnClickListener(v -> refreshCatalog());
        toolbar.addView(refresh, new LinearLayout.LayoutParams(dp(62), dp(38)));
        page.addView(toolbar, params(-1, dp(54)));

        LinearLayout previewCard = card();
        previewCard.setOrientation(LinearLayout.VERTICAL);
        previewCard.setPadding(dp(12), dp(12), dp(12), dp(12));
        TextView hint = text("七合一布局预览", 14, MUTED, true);
        hint.setPadding(dp(6), 0, 0, dp(6));
        previewCard.addView(hint, params(-1, -2));
        preview = new PreviewLayout();
        for (int i = 0; i < 7; i++) {
            PreviewSlot slot = new PreviewSlot(i, i < 3);
            final int position = i;
            slot.setOnClickListener(v -> chooseSlot(position));
            preview.addView(slot);
        }
        previewCard.addView(preview, new LinearLayout.LayoutParams(-1, dp(360)));
        page.addView(previewCard, topParams(-1, -2, 16));

        configStatus = text("每个圆盘都可以放置任意一个已检测磁贴", 13, MUTED, false);
        configStatus.setPadding(dp(14), dp(12), dp(14), dp(12));
        configStatus.setBackground(rounded(CARD, 18));
        configStatus.setOnClickListener(v -> refreshCatalog());
        page.addView(configStatus, topParams(-1, -2, 12));

        Button save = primaryButton("保存并写入配置");
        save.setOnClickListener(v -> saveConfig());
        page.addView(save, topParams(-1, dp(50), 14));
        page.addView(text("保存后 SystemUI 会自动同步；重启 SystemUI 也会保留顺序。",
            12, MUTED, false), topParams(-1, -2, 9));
        scroll.addView(page);
        refreshPreview();
        return scroll;
    }

    private static final class AvatarView extends ImageView {
        private final android.graphics.Path clip = new android.graphics.Path();
        AvatarView(android.content.Context context) { super(context); }
        @Override protected void onDraw(android.graphics.Canvas canvas) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float radius = Math.min(getWidth(), getHeight()) / 2f;
            clip.reset();
            clip.addCircle(cx, cy, radius, android.graphics.Path.Direction.CW);
            int save = canvas.save();
            canvas.clipPath(clip);
            super.onDraw(canvas);
            canvas.restoreToCount(save);
        }
    }

    private final class PreviewLayout extends ViewGroup {
        PreviewLayout() { super(MainActivity.this); setClipChildren(false); setClipToPadding(false); }
        @Override protected void onMeasure(int ws, int hs) {
            int width = MeasureSpec.getSize(ws);
            int height = MeasureSpec.getMode(hs) == MeasureSpec.UNSPECIFIED ? dp(360) : MeasureSpec.getSize(hs);
            int big = dp(92), small = dp(48);
            for (int i = 0; i < getChildCount(); i++) {
                int size = i < 3 ? big : small;
                getChildAt(i).measure(MeasureSpec.makeMeasureSpec(size, MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(size, MeasureSpec.EXACTLY));
            }
            setMeasuredDimension(width, height);
        }
        @Override protected void onLayout(boolean changed, int l, int t, int r, int b) {
            int w = r - l, h = b - t, pad = dp(25), gap = dp(12);
            int big = dp(92), small = dp(48);
            if (getChildCount() >= 3) {
                getChildAt(0).layout(pad, pad, pad + big, pad + big);
                getChildAt(1).layout(w - pad - big, pad, w - pad, pad + big);
                getChildAt(2).layout(pad, h - pad - big, pad + big, h - pad);
            }
            int x = w - pad - 2 * small - gap;
            int y = h - pad - 2 * small - gap;
            for (int i = 3; i < Math.min(7, getChildCount()); i++) {
                int n = i - 3, cx = x + (n % 2) * (small + gap), cy = y + (n / 2) * (small + gap);
                getChildAt(i).layout(cx, cy, cx + small, cy + small);
            }
        }
    }

    private final class PreviewSlot extends TextView {
        final int index;
        final boolean big;
        PreviewSlot(int index, boolean big) {
            super(MainActivity.this);
            this.index = index; this.big = big;
            setGravity(Gravity.CENTER);
            setTextColor(TEXT);
            setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            setTextSize(big ? 12 : 10);
            setMaxLines(big ? 2 : 1);
            setPadding(dp(3), dp(3), dp(3), dp(3));
                setBackground(big ? oval(CARD, 0xFFD9E2F0) : rounded(CARD, 17));
        }
    }

    private void refreshPreview() {
        if (preview == null) return;
        for (int i = 0; i < preview.getChildCount(); i++) {
            PreviewSlot slot = (PreviewSlot) preview.getChildAt(i);
            String id = i < selected.size() ? selected.get(i) : "";
            String label = id.isEmpty() ? "未设置" : nameOf(id);
            slot.setText(slot.big ? symbolOf(id) + "\n" + label : symbolOf(id));
            slot.setContentDescription("第" + (i + 1) + "项：" + label + "，点击更换");
        }
    }

    private void chooseSlot(final int slot) {
        if (catalog.isEmpty()) { toast("还没有检测到可用磁贴"); return; }
        String[] names = new String[catalog.size()];
        for (int i = 0; i < catalog.size(); i++) names[i] = nameOf(catalog.get(i));
        int checked = slot < selected.size() ? catalog.indexOf(selected.get(slot)) : -1;
        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle("选择第" + (slot + 1) + "项磁贴")
            .setSingleChoiceItems(names, checked, (d, which) -> {
                placeSlot(slot, catalog.get(which));
                d.dismiss();
            })
            .setNegativeButton("取消", null)
            .create();
        dialog.show();
    }

    private void placeSlot(int slot, String id) {
        while (selected.size() < 7) selected.add(TileCatalog.DEFAULT[selected.size()]);
        if (slot < 0 || slot >= selected.size()) return;
        int other = selected.indexOf(id);
        String old = selected.get(slot);
        if (other >= 0 && other != slot) selected.set(other, old);
        selected.set(slot, id);
        refreshPreview();
        if (configStatus != null) configStatus.setText("已更换第" + (slot + 1) + "项：" + nameOf(id) + "，点击保存后写入 SystemUI");
    }

    private void refreshCatalog() {
        try { getContentResolver().call(SevenProvider.URI, "request_catalog", null, new Bundle()); }
        catch (Throwable ignored) { }
        if (configStatus != null) configStatus.setText("正在检测本机可用磁贴…");
        new Handler(getMainLooper()).postDelayed(() -> {
            mergeCatalog();
            refreshPreview();
            if (configStatus != null) configStatus.setText("已检测到 " + catalog.size() + " 项可适配磁贴，点击圆盘即可选择");
        }, 1200);
    }

    private void readGlobalCatalog() {
        try {
            String raw = globalString(getContentResolver(), "dafeiyu_seveninone_catalog_v1");
            if (raw == null || raw.isEmpty()) return;
            org.json.JSONArray items = new org.json.JSONObject(raw).optJSONArray("items");
            if (items == null) return;
            for (int i = 0; i < items.length(); i++) {
                org.json.JSONObject item = items.optJSONObject(i);
                if (item == null) continue;
                String spec = item.optString("spec", "");
                if (spec.isEmpty()) continue;
                String label = item.optString("label", "");
                if (!labels.containsKey(spec) || label.length() > 0) labels.put(spec, label);
                if (!catalog.contains(spec)) catalog.add(spec);
            }
        } catch (Throwable ignored) { }
    }

    private static String globalString(android.content.ContentResolver cr, String key) {
        try {
            Class<?> type = Class.forName("android.provider.Settings$Global");
            Object value = type.getMethod("getString", android.content.ContentResolver.class, String.class)
                .invoke(null, cr, key);
            return value instanceof String ? (String) value : null;
        } catch (Throwable ignored) { return null; }
    }

    private String nameOf(String id) {
        String reported = labels.get(id);
        if (reported != null && !reported.isEmpty() && hasChinese(reported)) return reported;
        String localized = TileCatalog.localized(id);
        if (localized != null) return localized;
        if (reported != null && !reported.isEmpty()) return reported;
        String value = id;
        if (value.startsWith("custom(") && value.endsWith(")")) {
            String body = value.substring(7, value.length() - 1);
            int slash = body.indexOf('/');
            String pkg = slash > 0 ? body.substring(0, slash) : body;
            int dot = pkg.lastIndexOf('.');
            value = dot > 0 ? pkg.substring(dot + 1) : pkg;
        }
        return value.length() > 22 ? value.substring(0, 22) + "…" : value;
    }

    private static boolean hasChinese(String value) {
        for (int i = 0; i < value.length(); i++) if (value.charAt(i) >= '\u4e00' && value.charAt(i) <= '\u9fa5') return true;
        return false;
    }

    private String symbolOf(String id) { return TileCatalog.indexOf(id) < 0 ? "•" : TileCatalog.symbol(id); }

    private void saveConfig() {
        if (selected.size() < 3 || selected.size() > 7) { toast("请选择 3 到 7 项"); return; }
        Bundle extras = new Bundle(); extras.putStringArray("selected", selected.toArray(new String[0]));
        try {
            Bundle result = getContentResolver().call(SevenProvider.URI, "save_config", null, extras);
            if (result != null && result.getBoolean("ok", false)) {
                try { SevenProvider.pushConfig(this); } catch (Throwable ignored) { }
                if (configStatus != null) configStatus.setText("已保存并写入 SystemUI 展示配置");
                toast("配置已保存");
            } else toast(result == null ? "写入失败" : result.getString("message", "写入失败"));
        } catch (Throwable t) { toast("写入失败：" + t.getClass().getSimpleName()); }
    }

    private LinearLayout card() {
        LinearLayout v = new LinearLayout(this);
        v.setBackground(rounded(CARD, 24)); return v;
    }
    private TextView text(String value, float size, int color, boolean bold) {
        TextView v = new TextView(this); v.setText(value); v.setTextSize(size); v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setGravity(Gravity.CENTER_VERTICAL); return v;
    }
    private Button primaryButton(String value) {
        Button b = new Button(this); b.setText(value); b.setTextColor(Color.WHITE); b.setTextSize(15); b.setAllCaps(false);
        b.setBackground(rounded(ACCENT, 20)); return b;
    }
    private LinearLayout.LayoutParams params(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private LinearLayout.LayoutParams topParams(int w, int h, int top) {
        LinearLayout.LayoutParams p = params(w, h); p.topMargin = dp(top); return p;
    }
    private GradientDrawable rounded(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private GradientDrawable oval(int color, int stroke) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setShape(GradientDrawable.OVAL); d.setStroke(dp(1), stroke); return d; }
    private int statusBarHeight() { int id = getResources().getIdentifier("status_bar_height", "dimen", "android"); return id > 0 ? getResources().getDimensionPixelSize(id) : dp(28); }
    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + .5f); }
    private void toast(String value) { android.widget.Toast.makeText(this, value, android.widget.Toast.LENGTH_SHORT).show(); }
}
