package com.dafeiyu.seveninone.hook;

import com.dafeiyu.seveninone.oplusx.Z1;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/** SystemUI entry point for the OplusX-compatible seven-in-one port. */
public final class SevenInOneHook implements IXposedHookLoadPackage {
    @Override public void handleLoadPackage(XC_LoadPackage.LoadPackageParam param) {
        if (!"com.android.systemui".equals(param.packageName)) return;
        try {
            Z1.install(param.classLoader);
            XposedBridge.log("[SevenInOne/OplusXPort] SystemUI combo hooks installed");
        } catch (Throwable t) {
            XposedBridge.log("[SevenInOne/OplusXPort] install failed: " + t);
        }
    }
}
