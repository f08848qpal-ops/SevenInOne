package com.dafeiyu.seveninone.oplusx;

import android.content.Context;

/** Capability persistence is optional; the UI can work from the live QS host. */
final class PortConfigCapabilities {
    private PortConfigCapabilities() {}
    static void record(Context context, String json) { }
}
