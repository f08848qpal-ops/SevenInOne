package com.dafeiyu.seveninone.oplusx;

import android.app.Application;
import android.app.Dialog;
import android.content.Context;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.dafeiyu.seveninone.SevenProvider;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import java.lang.ref.WeakReference;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.function.Consumer;

/**
 * OplusX-compatible SystemUI side. This is intentionally reflection based:
 * SystemUI's private classes stay in the host process and are never packaged.
 */
public final class Z1 {
    static final String SPEC = D1.SPEC;
    static final String TILE_VIEW = "com.oplus.systemui.plugins.qs.customize.view.tile.";
    static final String CONFIG_REPO = "com.oplus.systemui.plugins.qs.customize.data.repo.";
    static final String CONFIG_MODEL = "com.oplus.systemui.plugins.qs.customize.data.model.";
    static final String SYSTEMUI = "com.android.systemui";
    static final Handler MAIN = new Handler(Looper.getMainLooper());
    static final Map<View, WeakReference<R1>> VIEWS =
        Collections.synchronizedMap(new WeakHashMap<View, WeakReference<R1>>());
    static final ArrayList<XC_MethodHook.Unhook> HOOKS = new ArrayList<>();
    static final Set<String> LOGGED = Collections.synchronizedSet(new HashSet<String>());
    static final Map<String, Holder> TILES = new HashMap<>();
    static ClassLoader loader;
    static Context context;
    static Object host;
    static Handler worker;
    static volatile D1 model = null; // 等待 context 启动时从 Provider 加载
    static volatile boolean installed;
    static volatile boolean reloading;

    private Z1() {}

    private static String[] defaultSpecs() {
        return new String[] {"wifi", "hotspot", "cell", "custom(com.coloros.phonemanager/com.oplus.phonemanager.dustclean.DustCleanTileService)",
            "custom(com.luckyzyx.luckytool/.service.tiles.BypassPowerModeTile)",
            "custom(com.luckyzyx.luckytool/.service.tiles.ExtraDimModeTile)",
            "custom(app.getlux.com.sakuracat.app/.VpnTileService)"};
    }

    static boolean enabled() { return context != null && PortConfig.enabled(context); }
    static boolean showLabels() { return context != null && PortConfig.showLabels(context); }
    static boolean longPressExpand() { return context == null || PortConfig.longPressExpand(context); }
    static D1 config() {
        D1 value = model;
        return value == null ? new D1(7, com.dafeiyu.seveninone.TileCatalog.DEFAULT.clone()) : value;
    }

    static Class<?> find(String name) { return XposedHelpers.findClass(name, loader); }
    static Class<?> findIf(String name) { return XposedHelpers.findClassIfExists(name, loader); }
    static Object call(Object target, String method, Object... args) {
        return XposedHelpers.callMethod(target, method, args);
    }
    static Object field(Object target, String name) { return XposedHelpers.getObjectField(target, name); }
    static void set(Object target, String name, Object value) {
        XposedHelpers.setObjectField(target, name, value);
    }
    static String stringField(Object target, String name) {
        try { Object value = field(target, name); return value == null ? null : String.valueOf(value); }
        catch (Throwable ignored) { return null; }
    }
    static void log(String message) { if (LOGGED.add(message)) XposedBridge.log("[SevenInOne/OplusXPort] " + message); }
    static void log(String message, Throwable error) { XposedBridge.log("[SevenInOne/OplusXPort] " + message + ": " + error); }

    public static synchronized void install(ClassLoader classLoader) {
        if (installed) return;
        loader = classLoader;
        try { hookApplication(); } catch (Throwable t) { log("Application hook unavailable", t); }
        try { hookFactories(); } catch (Throwable t) { log("QS factory hook unavailable", t); }
        try { hookHost(); } catch (Throwable t) { log("QS host hook unavailable", t); }
        try { hookRepositories(); } catch (Throwable t) { log("repository hook unavailable", t); }
        try { hookViews(); } catch (Throwable t) { log("view hook unavailable", t); }
        try { hookBack(); } catch (Throwable t) { log("back hook unavailable", t); }
        try { hookShadeDialog(); } catch (Throwable t) { log("detail dialog hook unavailable", t); }
        installed = true;
        log("OplusX-compatible combo hooks loaded");
    }

    private static void hookApplication() {
        HOOKS.addAll(XposedBridge.hookAllMethods(Application.class, "onCreate", new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam param) {
                try {
                    Application app = (Application) param.thisObject;
                    if (SYSTEMUI.equals(app.getPackageName())) start(app);
                } catch (Throwable t) { log("SystemUI context start failed", t); }
            }
        }));
    }

    private static void hookFactories() {
        String[] names = {"com.oplus.systemui.qs.tileimpl.OplusQSFactoryImpl",
            "com.android.systemui.qs.tileimpl.QSFactoryImpl",
            "com.android.systemui.qs.tileimpl.NewQSTileFactory"};
        for (String name : names) {
            Class<?> type = findIf(name);
            if (type == null) continue;
            HOOKS.addAll(XposedBridge.hookAllMethods(type, "createTile", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam param) {
                    try {
                        if (param.args != null && param.args.length == 1 && SPEC.equals(String.valueOf(param.args[0])) && enabled())
                            param.setResult(FakeTileHandler.create());
                    } catch (Throwable t) { log("fake tile creation failed", t); }
                }
            }));
        }
    }

    private static void hookHost() {
        Class<?> type = findIf("com.android.systemui.qs.QSHostAdapter");
        if (type == null) return;
        HOOKS.addAll(XposedBridge.hookAllConstructors(type, new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam param) {
                host = param.thisObject;
                try { start((Context) call(host, "getContext")); } catch (Throwable t) { log("host context unavailable", t); }
                reload();
            }
        }));
    }

    private static void hookRepositories() {
        final Class<?> staticRepo = findIf(CONFIG_REPO + "SepStaticTileConfigRepository");
        final Class<?> moreRepo = findIf(CONFIG_REPO + "SepMoreTileConfigRepository");
        rememberRepositories(staticRepo, moreRepo);
        final Class<?> companion = findIf(CONFIG_MODEL + "TileStaticConfig$Companion");
        log("repo classes static=" + (staticRepo != null) + " more=" + (moreRepo != null) + " companion=" + (companion != null));
        if (companion != null) {
            hookAll(companion, "createDefault", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) throws Throwable {
                    if (hasSpecArg(p)) p.setResult(staticConfig());
                }
            });
        }
        if (staticRepo != null) {
            hookAll(staticRepo, "getTileConfig", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) throws Throwable {
                    if (hasSpecArg(p)) p.setResult(staticConfig());
                }
            });
            hookAll(staticRepo, "getTileConfigs", new AddConfigHook());
        }
        if (moreRepo != null) {
            hookAll(moreRepo, "getConnectivityTileSpecs", new AddConnectivityConfigHook());
            hookAll(moreRepo, "getPreviewConfig", new AddPreviewTypeHook());
            hookAll(moreRepo, "getDisplayTileSpecs", new CatalogOnlyHook());
            hookAll(moreRepo, "getToolsTilesSpec", new CatalogOnlyHook());
            hookAll(moreRepo, "getOtherSystemTilesSpec", new CatalogOnlyHook());
            hookAll(moreRepo, "getTypeBySpec", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) throws Throwable {
                    if (hasSpecArg(p)) {
                        Class<?> tileType = findIf(CONFIG_MODEL.replace("customize.data.model.", "customize.data.") + "SepTileType");
                        if (tileType == null) tileType = findIf("com.oplus.systemui.plugins.qs.customize.data.SepTileType");
                        if (tileType != null) p.setResult(XposedHelpers.getStaticObjectField(tileType, "CONNECTIVITY"));
                    }
                }
            });
        }
        Class<?> moreLoader = findIf(CONFIG_REPO + "SepMoreTileConfigRepository$loadDataFromXMLByLock$2");
        if (moreLoader != null) hookAll(moreLoader, "invokeSuspend", new AddPreviewTypeHook());
        Class<?> staticLoader = findIf(CONFIG_REPO + "SepStaticTileConfigRepository$loadTilesLocked$2");
        if (staticLoader != null) hookAll(staticLoader, "invokeSuspend", new AddConfigHook());
    }

    private static boolean hasSpecArg(XC_MethodHook.MethodHookParam p) {
        return p.args != null && p.args.length > 0 && SPEC.equals(String.valueOf(p.args[0]));
    }
    private static boolean suspended(Object result) {
        return result != null && String.valueOf(result).contains("COROUTINE_SUSPENDED");
    }
    private static void hookAll(Class<?> type, String name, XC_MethodHook hook) {
        try { HOOKS.addAll(XposedBridge.hookAllMethods(type, name, hook)); }
        catch (Throwable t) { log("hook " + type.getName() + "." + name + " failed", t); }
    }

    private static String lastCatalog;

    /** Report every tile spec this device can offer, so the settings page can
     *  list the real catalogue instead of a hard-coded shortlist. */
    private static void reportCatalog(Object source) {
        try {
            ArrayList<String> specs = new ArrayList<>();
            collectSpecs(source, specs, 0);
            if (specs.isEmpty() || context == null) return;
            StringBuilder key = new StringBuilder();
            for (String spec : specs) key.append(spec).append(',');
            String joined = key.toString();
            if (joined.equals(lastCatalog)) return;
            lastCatalog = joined;
            android.os.Bundle args = new android.os.Bundle();
            args.putStringArray("specs", specs.toArray(new String[0]));
            context.getContentResolver().call(
                android.net.Uri.parse("content://com.dafeiyu.seveninone.provider/control"),
                "report_tiles", null, args);
            writeCatalogToGlobal(specs);
            log("tile catalog reported size=" + specs.size());
        } catch (Throwable t) { log("tile catalog report failed", t); }
    }

    static final String CATALOG_GLOBAL = "dafeiyu_seveninone_catalog_v1";

    /** Settings.Global is missing from the compile stub, so call it reflectively. */
    private static void globalPut(String key, String value) {
        try {
            Class<?> type = Class.forName("android.provider.Settings$Global");
            type.getMethod("putString", android.content.ContentResolver.class, String.class, String.class)
                .invoke(null, context.getContentResolver(), key, value);
        } catch (Throwable t) { log("catalog global write failed", t); }
    }

    /** Same trick as OplusX: publish the catalogue through Settings.Global.
     *  Labels are resolved one spec at a time from the ROM's own QSTile, so a
     *  device in any language gets its own localized names. */
    private static void writeCatalogToGlobal(java.util.List<String> specs) {
        if (context == null || specs == null || specs.isEmpty()) return;
        final org.json.JSONArray items = new org.json.JSONArray();
        for (String spec : specs) {
            try {
                org.json.JSONObject item = new org.json.JSONObject();
                item.put("spec", spec);
                item.put("label", "");
                items.put(item);
            } catch (Throwable ignored) { }
        }
        publishCatalog(items, 0);
    }

    private static void publishCatalog(final org.json.JSONArray items, final int index) {
        if (context == null) return;
        if (index >= items.length()) {
            try {
                org.json.JSONObject root = new org.json.JSONObject();
                root.put("version", 1);
                root.put("items", items);
                root.put("build", android.os.Build.FINGERPRINT);
                globalPut(CATALOG_GLOBAL, root.toString());
                log("catalog published items=" + items.length());
            } catch (Throwable t) { log("catalog publish failed", t); }
            return;
        }
        MAIN.postDelayed(() -> {
            try {
                org.json.JSONObject item = items.optJSONObject(index);
                if (item != null) {
                    String label = resolveTileLabel(item.optString("spec", ""));
                    if (!label.isEmpty()) item.put("label", label);
                }
            } catch (Throwable ignored) { }
            publishCatalog(items, index + 1);
        }, 1);
    }

    /** Ask the ROM's own tile for its localized label. */
    private static String resolveTileLabel(String spec) {
        if (spec == null || spec.isEmpty() || host == null) return "";
        TileHandle handle = null;
        try {
            handle = acquire(spec);
            if (handle == null) return "";
            Object value = call(handle.tile(), "getTileLabel");
            String text = value == null ? "" : value.toString().trim();
            if (text.length() > 28) text = text.substring(0, 28);
            return text;
        } catch (Throwable t) {
            return "";
        } finally {
            if (handle != null) { try { handle.close(); } catch (Throwable ignored) { } }
        }
    }

    /** Read the ROM getters directly whenever a repository instance exists. */
    static void scanCatalogRefs() {
        boolean found = false;
        try {
            if (staticRepoRef != null) {
                String[] names = {"getTileConfigs", "getTileConfig"};
                for (String name : names) {
                    try {
                        Object value = call(staticRepoRef, name);
                        if (value != null) { reportCatalog(value); found = true; }
                    } catch (Throwable ignored) { }
                }
            }
        } catch (Throwable t) { log("static repo scan failed", t); }
        try {
            if (moreRepoRef != null) {
                String[] names = {"getPreviewConfig", "getConnectivityTileSpecs",
                    "getDisplayTileSpecs", "getToolsTilesSpec", "getOtherSystemTilesSpec"};
                for (String name : names) {
                    try {
                        Object value = call(moreRepoRef, name);
                        if (value != null) { reportCatalog(value); found = true; }
                    } catch (Throwable ignored) { }
                }
            }
        } catch (Throwable t) { log("more repo scan failed", t); }
        log("catalog refs scan done, found=" + found);
    }

    private static void collectSpecs(Object node, ArrayList<String> out, int depth) {
        if (node == null || depth > 3 || out.size() >= 400) return;
        if (node instanceof java.util.Map) {
            for (Object value : ((java.util.Map<?, ?>) node).values()) collectSpecs(value, out, depth + 1);
            return;
        }
        if (node instanceof Iterable) {
            for (Object item : (Iterable<?>) node) collectSpecs(item, out, depth + 1);
            return;
        }
        String spec = null;
        try { spec = tileSpec(node); } catch (Throwable ignored) { }
        if (spec != null && !spec.isEmpty()
                && !spec.startsWith("innerFake_")
                && !spec.startsWith("oplusx_")
                && !spec.startsWith("dafeiyu_")
                && com.dafeiyu.seveninone.SevenProvider.isValidSpec(spec)
                && !out.contains(spec)) out.add(spec);
        Object children = null;
        try { children = call(node, "getTileList"); } catch (Throwable ignored) { }
        if (children != null && children != node) collectSpecs(children, out, depth + 1);
    }

    /** Collect-only hook for the ROM getters that only feed the tile catalogue. */
    private static final class CatalogOnlyHook extends XC_MethodHook {
        @Override protected void afterHookedMethod(MethodHookParam p) {
            reportCatalog(p.getResult());
        }
    }

    private static final class AddConfigHook extends XC_MethodHook {
        @Override protected void afterHookedMethod(MethodHookParam p) throws Throwable {
            Object result = p.getResult();
            reportCatalog(result);
            if (result instanceof Map) {
                LinkedHashMap<Object,Object> copy = new LinkedHashMap<>((Map<?,?>) result);
                copy.put(SPEC, staticConfig()); p.setResult(copy);
            } else if (result instanceof List) {
                ArrayList<Object> copy = new ArrayList<>((List<?>) result);
                boolean found = false;
                for (Object item : copy) if (SPEC.equals(tileSpec(item))) { found = true; break; }
                if (!found) copy.add(staticConfig());
                p.setResult(copy);
            }
        }
    }
    private static final class AddConnectivityConfigHook extends XC_MethodHook {
        @Override protected void afterHookedMethod(XC_MethodHook.MethodHookParam p) throws Throwable {
            Object result = p.getResult();
            log("connectivity hook result=" + (result == null ? "null" : result.getClass().getName()) + " size=" + (result instanceof java.util.Collection ? ((java.util.Collection<?>) result).size() : -1));
            reportCatalog(result);
            if (result instanceof List) {
                ArrayList<Object> copy = new ArrayList<>((List<?>) result);
                boolean found = false;
                for (Object item : copy) if (SPEC.equals(tileSpec(item))) { found = true; break; }
                if (!found) copy.add(staticConfig());
                p.setResult(copy);
            } else if (result instanceof Map) {
                LinkedHashMap<Object,Object> copy = new LinkedHashMap<>((Map<?,?>) result);
                copy.put(SPEC, staticConfig()); p.setResult(copy);
            }
        }
    }
    private static final class AddPreviewTypeHook extends XC_MethodHook {
        @Override protected void afterHookedMethod(XC_MethodHook.MethodHookParam p) throws Throwable {
            Object result = p.getResult();
            log("preview type hook result=" + (result == null ? "null" : result.getClass().getName()) + " size=" + (result instanceof java.util.Collection ? ((java.util.Collection<?>) result).size() : -1));
            reportCatalog(result);
            if (!(result instanceof List)) return;
            ArrayList<Object> output = new ArrayList<>();
            boolean connectivity = false;
            for (Object config : (List<?>) result) {
                Object type = null;
                Object listObject = null;
                try { type = call(config, "getTileType"); listObject = call(config, "getTileList"); } catch (Throwable ignored) { }
                if ("CONNECTIVITY".equals(String.valueOf(type)) && listObject instanceof List) {
                    connectivity = true;
                    ArrayList<Object> tiles = new ArrayList<>((List<?>) listObject);
                    boolean found = false;
                    for (Object tile : tiles) if (SPEC.equals(tileSpec(tile))) { found = true; break; }
                    if (!found) tiles.add(preview());
                    Class<?> model = find(CONFIG_MODEL + "TileTypeConfig");
                    config = XposedHelpers.newInstance(model, type, tiles);
                }
                output.add(config);
            }
            if (!connectivity) {
                Class<?> enumType = findIf("com.oplus.systemui.plugins.qs.customize.data.SepTileType");
                Class<?> model = find(CONFIG_MODEL + "TileTypeConfig");
                if (enumType != null) output.add(XposedHelpers.newInstance(model,
                    XposedHelpers.getStaticObjectField(enumType, "CONNECTIVITY"), Collections.singletonList(preview())));
            }
            p.setResult(output);
        }
    }

    private static final class AddPreviewHook extends XC_MethodHook {
        @Override protected void afterHookedMethod(MethodHookParam p) throws Throwable {
            Object result = p.getResult();
            if (result instanceof List) {
                ArrayList<Object> copy = new ArrayList<>((List<?>) result);
                boolean found = false;
                for (Object item : copy) if (SPEC.equals(tileSpec(item))) { found = true; break; }
                if (!found) copy.add(preview());
                p.setResult(copy);
            } else if (result instanceof Map) {
                LinkedHashMap<Object,Object> copy = new LinkedHashMap<>((Map<?,?>) result);
                copy.put(SPEC, preview()); p.setResult(copy);
            }
        }
    }

    private static String tileSpec(Object tile) {
        if (tile == null) return "";
        try { return String.valueOf(call(tile, "getTileSpec")); } catch (Throwable ignored) { return ""; }
    }

    static void prepareNativeChild(View view) throws Throwable {
        Object size = span(1, 1);
        Class<?> calc = find("com.oplus.systemui.qs.CellCalculatorManager");
        Object instance = call(XposedHelpers.getStaticObjectField(calc, "Companion"), "getInstance", view.getContext());
        Boolean falseValue = Boolean.FALSE;
        call(view, "handleCellLayoutConstraintChanged", XposedHelpers.callStaticMethod(
            calc, "getLayoutConstraint$default", instance, size, falseValue, falseValue, 14));
        java.util.List<Object> one = java.util.Collections.singletonList(size);
        call(view, "onOutlineUpdate", one);
        call(view, "onDrawableUpdate", one, falseValue);
        call(view, "onDrawableUpdate", one, Boolean.TRUE);
        Class<?> pool = find("com.oplus.systemui.qs.base.res.BaseQSResPool");
        Object poolInstance = XposedHelpers.getStaticObjectField(pool, "INSTANCE");
        call(view, "onThemeApplied", call(poolInstance, "globalThemeApplied"));
    }

    static Object span(int width, int height) throws Throwable {
        Class<?> cache = find("com.oplusos.systemui.common.model.SpanCache");
        Object instance = XposedHelpers.getStaticObjectField(cache, "INSTANCE");
        return call(instance, "spanSize", Integer.valueOf(width), Integer.valueOf(height));
    }
    static Object staticConfig() throws Throwable {
        Object size = span(2, 2);
        Class<?> type = find(CONFIG_MODEL + "TileStaticConfig");
        return XposedHelpers.newInstance(type, SPEC, size, Collections.singletonList(size));
    }
    static Object preview() throws Throwable {
        Object icon = null;
        android.graphics.drawable.Drawable appIcon = null;
        // Use this module's own launcher icon in the "add tile" picker.
        try {
            appIcon = context.getPackageManager().getApplicationIcon("com.dafeiyu.seveninone");
        } catch (Throwable t) { log("module icon unavailable", t); }
        if (appIcon == null) {
            try {
                int id = context.getResources().getIdentifier("ic_qs_wifi_disconnected", "drawable", SYSTEMUI);
                Class<?> resourceIcon = find("com.android.systemui.qs.tileimpl.QSTileImpl$ResourceIcon");
                icon = XposedHelpers.callStaticMethod(resourceIcon, "get", Integer.valueOf(id));
            } catch (Throwable ignored) { }
        }
        Class<?> type = find(CONFIG_MODEL + "TilePreviewsData");
        return XposedHelpers.newInstance(type, SPEC, D1.LABEL, icon, appIcon, span(2, 2), "");
    }

    private static void hookViews() throws Throwable {
        final Class<?> base = find(TILE_VIEW + "OplusQSResizeableTileView");
        final Class<?> two = find(TILE_VIEW + "OplusQSResizeableTileViewTwoXTwo");
        hookAll(base, "init", new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam p) {
                try {
                    if (!(p.thisObject instanceof ViewGroup) || p.args == null || p.args.length != 1) return;
                    Object tile = p.args[0];
                    if (!SPEC.equals(tileSpec(tile))) return;
                    R1 combo = get((View) p.thisObject);
                    if (combo == null && two.isInstance(p.thisObject)) {
                        combo = new R1((ViewGroup) p.thisObject, handlerOf(tile));
                        combo.attach();
                        put((View) p.thisObject, combo);
                    }
                    if (combo != null && handlerOf(tile) != null) handlerOf(tile).bind(combo);
                } catch (Throwable t) { log("2x2 combo attach failed", t); }
            }
        });
        hookAll(two, "handleTileStateChange", new RefreshHook());
        hookAll(two, "handleEditModeChanged", new RefreshHook());
        hookAll(two, "onDrawableUpdate", new RefreshHook());
        hookAll(two, "onThemeApplied", new RefreshHook());
        hookAll(two, "onRecycle", new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) { detach((View) p.thisObject); }
        });
        hookAll(base, "setEditMode", new RefreshHook());
    }
    private static final class RefreshHook extends XC_MethodHook {
        @Override protected void afterHookedMethod(MethodHookParam p) {
            R1 combo = get((View) p.thisObject); if (combo != null) combo.refresh();
        }
    }
    static R1 get(View view) {
        WeakReference<R1> ref = VIEWS.get(view); return ref == null ? null : ref.get();
    }
    static void put(View view, R1 combo) { VIEWS.put(view, new WeakReference<R1>(combo)); }
    static void detach(View view) {
        R1 combo = get(view);
        VIEWS.remove(view);
        if (combo != null) combo.destroy();
    }
    static FakeTileHandler handlerOf(Object tile) {
        try {
            if (tile != null && Proxy.isProxyClass(tile.getClass())) {
                InvocationHandler h = Proxy.getInvocationHandler(tile);
                return h instanceof FakeTileHandler ? (FakeTileHandler) h : null;
            }
        } catch (Throwable ignored) { }
        return null;
    }

    /** Provider registration can lag behind SystemUI after a restart. Retry
     *  reading it; PortConfig itself falls back to the global cache. */
    private static void retryConfig(final int attempt) {
        if (context == null || attempt >= 8) return;
        MAIN.postDelayed(() -> {
            if (context == null) return;
            D1 loaded = PortConfig.read(context);
            model = loaded;
            for (R1 combo : allViews()) combo.refresh();
            if (attempt + 1 < 8) retryConfig(attempt + 1);
        }, 1500L * (attempt + 1));
    }

    static void start(Context c) {
        if (c == null) return;
        if (context == null) {
            context = c.getApplicationContext();
            D1 loaded = PortConfig.read(context);
            model = loaded;
            log("SystemUI context started, config=" + model.count + " (loaded from provider)");
            HandlerThread thread = new HandlerThread("SevenInOne-OplusXPort");
            thread.start(); worker = new Handler(thread.getLooper());
            try { context.getContentResolver().registerContentObserver(SevenProvider.URI, false, new ConfigObserver(MAIN)); }
            catch (Throwable t) { log("provider observer unavailable", t); }
            installCatalogReceiver();
            MAIN.postDelayed(Z1::scanCatalog, 1500);
            MAIN.postDelayed(() -> retryConfig(0), 1800);
        }
        reload();
    }
    static Object catalogReceiver;
    static Object staticRepoRef;
    static Object moreRepoRef;
    private static boolean catalogScanned;

    /** The customize repositories are not guaranteed to be in Dependency, so
     *  keep whatever instance the ROM creates. */
    private static void rememberRepositories(Class<?> staticRepo, Class<?> moreRepo) {
        try {
            if (staticRepo != null) {
                HOOKS.addAll(XposedBridge.hookAllConstructors(staticRepo, new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        staticRepoRef = p.thisObject;
                        MAIN.postDelayed(Z1::scanCatalogRefs, 300);
                    }
                }));
            }
            if (moreRepo != null) {
                HOOKS.addAll(XposedBridge.hookAllConstructors(moreRepo, new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        moreRepoRef = p.thisObject;
                        MAIN.postDelayed(Z1::scanCatalogRefs, 300);
                    }
                }));
            }
        } catch (Throwable t) { log("repository ctor hook failed", t); }
    }

    private static Object dependencyOf(String className) {
        Class<?> type = findIf(className);
        if (type == null) return null;
        String[] holders = {"com.android.systemui.Dependency", "com.android.systemui.DependencyEx",
            "com.oplus.systemui.DependencyEx"};
        for (String holder : holders) {
            try {
                Class<?> holderType = findIf(holder);
                if (holderType == null) continue;
                Object service = XposedHelpers.getStaticObjectField(holderType, "sDependency");
                if (service == null) continue;
                Object value = call(service, "getDependencyInner", type);
                if (value == null) value = call(service, "getDependency", type);
                if (value != null) return value;
            } catch (Throwable ignored) { }
        }
        return null;
    }

    /** Ask the ROM for its own tile catalogue instead of waiting for the
     *  "add tile" page to run its hooks. */
    static void scanCatalog() {
        if (context == null) return;
        boolean found = false;
        try {
            Object repo = staticRepoRef != null ? staticRepoRef
                : dependencyOf(CONFIG_REPO + "SepStaticTileConfigRepository");
            if (repo != null) {
                Object configs = call(repo, "getTileConfigs");
                if (configs != null) { reportCatalog(configs); found = true; }
            }
        } catch (Throwable t) { log("static catalog scan failed", t); }
        try {
            Object repo = moreRepoRef != null ? moreRepoRef
                : dependencyOf(CONFIG_REPO + "SepMoreTileConfigRepository");
            if (repo != null) {
                Object specs = call(repo, "getConnectivityTileSpecs");
                if (specs != null) { reportCatalog(specs); found = true; }
                Object previews = call(repo, "getPreviewConfig");
                if (previews != null) { reportCatalog(previews); found = true; }
            }
        } catch (Throwable t) { log("more catalog scan failed", t); }
        catalogScanned = found;
        log("catalog scan done, found=" + found);
    }

    /** The settings app can request a catalogue scan and push the saved
     *  seven-item order without relying on a cold ContentProvider lookup. */
    static void installCatalogReceiver() {
        if (context == null || catalogReceiver != null) return;
        try {
            final android.content.BroadcastReceiver receiver = new android.content.BroadcastReceiver() {
                @Override public void onReceive(Context receiverContext, android.content.Intent intent) {
                    String action = intent == null ? null : intent.getAction();
                    if ("com.dafeiyu.seveninone.REQUEST_CATALOG".equals(action)) {
                        scanCatalog();
                        return;
                    }
                    if ("com.dafeiyu.seveninone.CONFIG_UPDATED".equals(action)) {
                        String[] selected = intent.getStringArrayExtra("selected");
                        if (selected == null || selected.length < 3 || selected.length > 7) return;
                        try {
                            D1 next = new D1(selected.length, selected);
                            model = next;
                            PortConfig.cache(context, next);
                            for (R1 combo : allViews()) combo.refresh();
                            log("config broadcast applied " + next.toJson());
                        } catch (Throwable t) { log("config broadcast failed", t); }
                    }
                }
            };
            android.content.IntentFilter filter = new android.content.IntentFilter();
            filter.addAction("com.dafeiyu.seveninone.REQUEST_CATALOG");
            filter.addAction("com.dafeiyu.seveninone.CONFIG_UPDATED");
            try {
                // RECEIVER_EXPORTED (2): the app process sends these explicit
                // broadcasts to SystemUI after saving/opening its settings.
                XposedHelpers.callMethod(context, "registerReceiver", receiver, filter, Integer.valueOf(2));
            } catch (Throwable t) {
                XposedHelpers.callMethod(context, "registerReceiver", receiver, filter);
            }
            catalogReceiver = receiver;
            log("catalog/config receiver installed");
        } catch (Throwable t) { log("catalog/config receiver failed", t); }
    }

    static void reload() {
        model = PortConfig.read(context);
        if (context == null || reloading) return;
        reloading = true;
        MAIN.post(() -> {
            try {
                model = PortConfig.read(context);
                for (R1 combo : allViews()) combo.refresh();
            } finally { reloading = false; }
        });
    }
    private static List<R1> allViews() {
        ArrayList<R1> result = new ArrayList<>();
        synchronized (VIEWS) {
            for (WeakReference<R1> ref : VIEWS.values()) { R1 combo = ref.get(); if (combo != null) result.add(combo); }
        }
        return result;
    }
    private static final class ConfigObserver extends ContentObserver {
        ConfigObserver(Handler handler) { super(handler); }
        @Override public void onChange(boolean selfChange, Uri uri) { reload(); }
    }

    static synchronized TileHandle acquire(String spec) {
        if (!D1.valid(spec) || host == null) return null;
        Holder holder = TILES.get(spec);
        try {
            if (holder == null || holder.tile == null || Boolean.TRUE.equals(call(holder.tile, "isDestroyed"))) {
                Object tile = null;
                Object all = call(host, "getTiles");
                if (all instanceof Collection) for (Object candidate : new ArrayList<Object>((Collection<?>) all)) {
                    if (spec.equals(tileSpec(candidate)) && !Boolean.TRUE.equals(call(candidate, "isDestroyed"))) { tile = candidate; break; }
                }
                boolean created = false;
                if (tile == null) { tile = call(host, "createTile", spec); created = true; }
                if (tile == null || !Boolean.TRUE.equals(call(tile, "isAvailable"))) {
                    if (created && tile != null) call(tile, "destroy");
                    return null;
                }
                holder = new Holder(tile, created); TILES.put(spec, holder);
            }
            holder.refs++;
            return new TileHandle(spec, holder);
        } catch (Throwable t) { log("native tile acquire failed: " + spec, t); return null; }
    }
    private static final class Holder {
        final Object tile; final boolean created; int refs;
        Holder(Object tile, boolean created) { this.tile = tile; this.created = created; }
    }
    static final class TileHandle {
        final String spec; final Holder holder; final Object token = new Object();
        Object callback; boolean closed;
        TileHandle(String spec, Holder holder) { this.spec = spec; this.holder = holder; }
        Object tile() { return holder.tile; }
        void start(final Consumer<Object> consumer) throws Throwable {
            final Class<?> callbackType = find("com.android.systemui.plugins.qs.QSTile$Callback");
            callback = Proxy.newProxyInstance(loader, new Class<?>[] {callbackType}, new InvocationHandler() {
                @Override public Object invoke(Object proxy, Method method, Object[] args) {
                    if ("onStateChanged".equals(method.getName()) && args != null && args.length > 0) {
                        final Object state = copyState(args[0]);
                        MAIN.post(() -> { if (!closed) consumer.accept(state); });
                    }
                    return defaultValue(method.getReturnType());
                }
            });
            call(tile(), "addCallback", callback);
            call(tile(), "setListening", token, Boolean.TRUE);
            call(tile(), "refreshState");
            consumer.accept(copyState(call(tile(), "getState")));
        }
        void click(View source) { invokeAction("click", source); }
        void detail(View source) {
            try {
                Object state = call(tile(), "getState");
                if (numberField(state, "state") == 0) return;
                Object expandable = expandable(source);
                if (Boolean.TRUE.equals(fieldValue(state, "dualTarget")) || Boolean.TRUE.equals(fieldValue(state, "handlesSecondaryClick")))
                    call(tile(), "secondaryClick", expandable);
                else if (Boolean.TRUE.equals(fieldValue(state, "handlesLongClick"))) call(tile(), "longClick", expandable);
            } catch (Throwable t) { log("native detail failed: " + spec, t); }
        }
        private void invokeAction(String name, View source) {
            try {
                Object state = call(tile(), "getState");
                if (numberField(state, "state") == 0 || Boolean.TRUE.equals(fieldValue(state, "disabledByPolicy"))) return;
                if (source != null) source.performHapticFeedback(6);
                call(tile(), name, expandable(source));
            } catch (Throwable t) { log("native " + name + " failed: " + spec, t); }
        }
        synchronized void close() {
            if (closed) return; closed = true;
            try { if (callback != null) call(tile(), "removeCallback", callback); } catch (Throwable ignored) { }
            try { call(tile(), "setListening", token, Boolean.FALSE); } catch (Throwable ignored) { }
            synchronized (Z1.class) {
                holder.refs--;
                if (holder.refs <= 0) {
                    TILES.remove(spec);
                    if (holder.created) try { call(holder.tile, "destroy"); } catch (Throwable ignored) { }
                }
            }
        }
    }

    static Object copyState(Object state) {
        try { return state == null ? null : call(state, "copy"); } catch (Throwable ignored) { return state; }
    }
    static Object expandable(View source) throws Throwable {
        Class<?> type = find("com.android.systemui.animation.Expandable");
        return XposedHelpers.callStaticMethod(type, "fromView", source);
    }
    static Object fieldValue(Object object, String name) {
        try { return object == null ? null : field(object, name); } catch (Throwable ignored) { return null; }
    }
    static int numberField(Object object, String name) {
        Object value = fieldValue(object, name); return value instanceof Number ? ((Number) value).intValue() : -1;
    }
    static Object defaultValue(Class<?> type) {
        if (!type.isPrimitive()) return null;
        if (type == Boolean.TYPE) return Boolean.FALSE;
        if (type == Integer.TYPE || type == Short.TYPE || type == Byte.TYPE || type == Character.TYPE) return 0;
        if (type == Long.TYPE) return 0L;
        if (type == Float.TYPE) return 0f;
        if (type == Double.TYPE) return 0d;
        return null;
    }

    static final class FakeTileHandler implements InvocationHandler {
        final Object nativeTile; final Object state; final Set<Object> callbacks = new CopyOnWriteArraySet<>();
        final Set<Object> listening = Collections.newSetFromMap(new IdentityHashMap<Object, Boolean>());
        volatile boolean destroyed; volatile R1 combo;
        FakeTileHandler() throws Throwable {
            Class<?> fake = findIf("com.oplus.systemui.qs.tiles.OplusInnerFakeTile");
            nativeTile = fake == null ? null : XposedHelpers.newInstance(fake, SPEC, Boolean.FALSE);
            state = nativeTile == null ? null : call(nativeTile, "getState");
            if (state != null) {
                set(state, "spec", SPEC); set(state, "label", D1.LABEL); set(state, "contentDescription", D1.LABEL);
                set(state, "state", Integer.valueOf(1)); set(state, "handlesLongClick", Boolean.TRUE); set(state, "handlesSecondaryClick", Boolean.TRUE);
                try {
                    int id = context.getResources().getIdentifier("ic_qs_wifi_disconnected", "drawable", SYSTEMUI);
                    Class<?> icon = find("com.android.systemui.qs.tileimpl.QSTileImpl$ResourceIcon");
                    set(state, "icon", XposedHelpers.callStaticMethod(icon, "get", Integer.valueOf(id)));
                } catch (Throwable ignored) { }
            }
        }
        Object proxy() throws Throwable {
            return Proxy.newProxyInstance(loader, new Class<?>[] {find("com.android.systemui.plugins.qs.QSTile")}, this);
        }
        void bind(R1 combo) { this.combo = combo; }
        void notifyState() { for (Object callback : callbacks) try { call(callback, "onStateChanged", copyState(state)); } catch (Throwable ignored) { } }
        @Override public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            String name = method.getName();
            if ("equals".equals(name)) return proxy == (args == null ? null : args[0]);
            if ("hashCode".equals(name)) return System.identityHashCode(proxy);
            if ("toString".equals(name) || "getTileSpec".equals(name) || "getMetricsSpec".equals(name)) return SPEC;
            if ("setTileSpec".equals(name)) return null;
            if ("getTileLabel".equals(name)) return D1.LABEL;
            if ("getState".equals(name)) return state;
            if ("getDefaultIcon".equals(name)) return fieldValue(state, "icon");
            if ("getTileIconSupplier".equals(name)) return fieldValue(state, "iconSupplier");
            if ("getInstanceId".equals(name)) return nativeTile == null ? 0 : call(nativeTile, "getInstanceId");
            if ("isAvailable".equals(name) || "isTileReady".equals(name)) return enabled() && !destroyed;
            if ("isDestroyed".equals(name)) return destroyed;
            if ("addCallback".equals(name)) { if (args != null && args.length > 0) { callbacks.add(args[0]); call(args[0], "onStateChanged", copyState(state)); } return null; }
            if ("removeCallback".equals(name)) { if (args != null && args.length > 0) callbacks.remove(args[0]); return null; }
            if ("removeCallbacks".equals(name)) { callbacks.clear(); return null; }
            if ("refreshState".equals(name) || "clearState".equals(name)) { notifyState(); return null; }
            if ("setListening".equals(name)) { if (args != null && args.length > 1) { synchronized (listening) { if (Boolean.TRUE.equals(args[1])) listening.add(args[0]); else listening.remove(args[0]); } } return null; }
            if ("isListening".equals(name)) { synchronized (listening) { return !listening.isEmpty(); } }
            if ("destroy".equals(name)) { destroyed = true; callbacks.clear(); synchronized (listening) { listening.clear(); } return null; }
            if ("click".equals(name) || "secondaryClick".equals(name) || "longClick".equals(name)) { if (combo != null) MAIN.post(() -> combo.outerAction(name)); return null; }
            if ("getCurrentTileUser".equals(name)) return host == null ? 0 : call(host, "getUserId");
            return defaultValue(method.getReturnType());
        }
        static FakeTileHandler of(Object tile) { return handlerOf(tile); }
        static Object create() throws Throwable { return new FakeTileHandler().proxy(); }
    }

    static View hiddenQsRoot;

    /**
     * The page must live inside the shade window: only there do the Oplus tile
     * views get a backdrop bitmap for their AGSL shade (and the liquid glass
     * hook). We hide the QS content root while it is open so the panel's own
     * blurred backdrop stays visible behind the cards.
     */
    static void showDetail(R1 combo) {
        if (context == null) return;
        try {
            View root = combo.getRootView();
            if (!(root instanceof ViewGroup)) return;
            float density = context.getResources().getDisplayMetrics().density;
            FrameLayout overlay = new FrameLayout(context);
            overlay.setClickable(true);
            overlay.setFocusable(true);
            overlay.setOnClickListener(v -> combo.closeDetail());
            ViewGroup frame = new FrameLayout(context);
            android.widget.ScrollView scroll = new android.widget.ScrollView(context);
            scroll.setFillViewport(false);
            scroll.setClipToPadding(false);
            scroll.addView(frame, new android.widget.FrameLayout.LayoutParams(-1, -2));
            FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(-1, -2,
                android.view.Gravity.CENTER_HORIZONTAL | android.view.Gravity.CENTER_VERTICAL);
            params.leftMargin = Math.round(20 * density);
            params.rightMargin = Math.round(20 * density);
            scroll.setAlpha(0f);
            overlay.addView(scroll, params);
            ViewGroup host = (ViewGroup) root;
            host.addView(overlay, new ViewGroup.LayoutParams(-1, -1));
            combo.prepareTileRect();
            hideQsContent(root);
            combo.setDetailOverlay(overlay);
            combo.setDetailContent(scroll);
            activeCombo = combo;
            overlay.setAlpha(1f);
            overlay.setScaleX(1f);
            overlay.setScaleY(1f);
            combo.populateDetail(frame, null);
            combo.playDetailEnter(scroll);
        } catch (Throwable t) { log("detail overlay failed", t); }
    }

    static Object backDispatcher;
    static Object backCallback;

    /** While the page is open, the back gesture must close it instead of
     *  collapsing the shade. */
    static void registerBack(final R1 combo, View anchor) {
        // Disabled on purpose: WindowOnBackInvokedDispatcher throws inside
        // registerOnBackInvokedCallbackUnchecked on this ROM, and the failed
        // call leaves the shade window dispatcher in a state where SystemUI's
        // own BackActionInteractor registration crashes. The onBackPressed hook
        // already covers the gesture.
        if (true) return;
        try {
            Object dispatcher = XposedHelpers.callMethod(anchor, "findOnBackInvokedDispatcher");
            if (dispatcher == null) return;
            Class<?> type = Class.forName("android.window.OnBackInvokedCallback", false, loader);
            Object callback = Proxy.newProxyInstance(loader, new Class<?>[] {type},
                (proxy, method, args) -> {
                    if ("onBackInvoked".equals(method.getName())) {
                        MAIN.post(combo::closeDetail);
                        return null;
                    }
                    return defaultValue(method.getReturnType());
                });
            XposedHelpers.callMethod(dispatcher, "registerOnBackInvokedCallback", Integer.valueOf(1000000), callback);
            backDispatcher = dispatcher;
            backCallback = callback;
            log("detail back callback registered");
        } catch (Throwable t) { log("detail back callback failed", t); }
    }

    static void unregisterBack() {
        if (backDispatcher == null || backCallback == null) return;
        try { XposedHelpers.callMethod(backDispatcher, "unregisterOnBackInvokedCallback", backCallback); }
        catch (Throwable t) { log("detail back unregister failed", t); }
        backDispatcher = null;
        backCallback = null;
    }

    static void hideQsContent(View root) {
        try {
            View target = findBySimpleName(root, "OplusQSRootView");
            if (target != null) {
                hiddenQsRoot = target;
                // Let the control centre dissolve during the first frames of
                // the page grow animation instead of switching off instantly.
                try { target.animate().cancel(); } catch (Throwable ignored) { }
                target.setVisibility(View.VISIBLE);
                target.setAlpha(1f);
                target.animate().alpha(0f).setDuration(110)
                    .setInterpolator(new android.view.animation.LinearInterpolator())
                    .withEndAction(() -> {
                        if (hiddenQsRoot == target) target.setVisibility(View.INVISIBLE);
                    }).start();
                log("QS content fading out for detail page");
            } else log("OplusQSRootView not found");
        } catch (Throwable t) { log("hide QS content failed", t); }
    }

    /** Bring the control centre back during the last frames of the page
     *  shrink instead of popping it in after the page is gone. */
    static void restoreQsContentAnimated(int delayMs, int durationMs) {
        final View target = hiddenQsRoot;
        if (target == null) return;
        hiddenQsRoot = null;
        try { target.animate().cancel(); } catch (Throwable ignored) { }
        try {
            target.setVisibility(View.VISIBLE);
            target.setAlpha(0f);
            target.animate().alpha(1f).setStartDelay(delayMs).setDuration(durationMs)
                .setInterpolator(new android.view.animation.LinearInterpolator()).start();
        } catch (Throwable ignored) { }
    }

    /** SystemUI re-shows the QS root on some panel state changes; keep it out
     *  of the way while our page is up. */
    static void ensureQsHidden() {
        if (hiddenQsRoot == null) return;
        try {
            hiddenQsRoot.setAlpha(0f);
            hiddenQsRoot.setVisibility(View.INVISIBLE);
        } catch (Throwable ignored) { }
    }

    static void restoreQsContent() {
        activeCombo = null;
        unregisterBack();
        if (hiddenQsRoot == null) return;
        try {
            hiddenQsRoot.setAlpha(1f);
            hiddenQsRoot.setVisibility(View.VISIBLE);
        } catch (Throwable ignored) { }
        hiddenQsRoot = null;
    }

    static View findBySimpleName(View view, String name) {
        if (view == null) return null;
        if (view.getClass().getSimpleName().equals(name)) return view;
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                View found = findBySimpleName(group.getChildAt(i), name);
                if (found != null) return found;
            }
        }
        return null;
    }

    /** Diagnostics: log the window view chain so the panel layers can be
     *  identified precisely instead of guessing. */
    static void dumpTree(View view) {
        try {
            StringBuilder chain = new StringBuilder();
            View cursor = view;
            while (cursor != null) {
                chain.append(cursor.getClass().getName()).append(" <- ");
                android.view.ViewParent parent = cursor.getParent();
                cursor = parent instanceof View ? (View) parent : null;
            }
            log("chain: " + chain);
            View root = view.getRootView();
            StringBuilder out = new StringBuilder();
            logTree(root, 0, out);
            String text = out.toString();
            for (int i = 0, part = 0; i < text.length(); i += 700, part++)
                log("tree[" + part + "]: " + text.substring(i, Math.min(text.length(), i + 700)));
        } catch (Throwable t) { log("dump tree failed", t); }
    }

    private static void logTree(View view, int depth, StringBuilder out) {
        if (view == null || depth > 6) return;
        for (int i = 0; i < depth; i++) out.append('.');
        out.append(view.getClass().getSimpleName());
        int id = view.getId();
        if (id != -1) out.append('#').append(Integer.toHexString(id));
        if (view instanceof ViewGroup) out.append('[').append(((ViewGroup) view).getChildCount()).append(']');
        out.append(' ');
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) logTree(group.getChildAt(i), depth + 1, out);
        }
    }

    static R1 activeCombo;

    /** The panel handles the back gesture in onBackPressed(); when our page is
     *  open the gesture must close the page instead of collapsing the shade. */
    private static void hookBack() {
        Class<?> type = findIf("com.android.systemui.shade.NotificationPanelViewController");
        if (type == null) return;
        Class<?> interactor = findIf("com.android.systemui.back.domain.interactor.BackActionInteractor");
        if (interactor != null) {
            HOOKS.addAll(XposedBridge.hookAllMethods(interactor, "onBackRequested", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam param) {
                    R1 combo = activeCombo;
                    if (combo != null && combo.isSuspended()) {
                        MAIN.postDelayed(combo::resumeDetail, 380);
                    }
                    if (combo != null && combo.hasDetail() && !combo.isSuspended()) {
                        MAIN.post(combo::closeDetail);
                        param.setResult(Boolean.TRUE);
                    }
                }
            }));
            log("back interactor hook installed");
        }
        HOOKS.addAll(XposedBridge.hookAllMethods(type, "onBackPressed", new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam param) {
                R1 combo = activeCombo;
                if (combo != null && combo.hasDetail()) {
                    MAIN.post(combo::closeDetail);
                    param.setResult(null);
                }
            }
        }));
    }

    static R1 reopenCombo;
    static View dialogDecor;

    /** A native tile detail is a dialog on top of the shade. While it is up our
     *  page must step aside, and it comes back once the dialog is dismissed. */
    private static void hookShadeDialog() {
        XC_MethodHook close = new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam param) {
                R1 combo = activeCombo;
                if (combo != null && combo.hasDetail()) MAIN.post(combo::suspendDetail);
            }
        };
        XC_MethodHook resume = new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam param) {
                R1 combo = activeCombo;
                if (combo != null && combo.isSuspended()) MAIN.post(combo::resumeDetail);
            }
        };
        Class<?> viewDialog = findIf("com.oplusos.systemui.viewdialog.domain.SysUIViewDialogInteractor");
        if (viewDialog != null) {
            HOOKS.addAll(XposedBridge.hookAllMethods(viewDialog, "showDialog", close));
            HOOKS.addAll(XposedBridge.hookAllMethods(viewDialog, "dismissDialog", resume));
            HOOKS.addAll(XposedBridge.hookAllMethods(viewDialog, "hideDialog", resume));
            log("view dialog hooks installed");
        }
        Class<?> type = findIf("com.oplus.systemui.common.dialog.OplusThemeSystemUiDialog");
        if (type != null) {
            HOOKS.addAll(XposedBridge.hookAllMethods(type, "show", close));
            HOOKS.addAll(XposedBridge.hookAllMethods(type, "dismiss", resume));
            HOOKS.addAll(XposedBridge.hookAllMethods(type, "cancel", resume));
        }
    }

    static View behindPanel;
    static float behindPanelAlpha = 1f;

    /** BackgroundBlurDrawable only samples what is behind the window, so the
     *  panel itself has to get out of the way for the backdrop to show the
     *  launcher instead of the control centre tiles. */
    static void hidePanelBehind() {
        try {
            Object ex = DetailShell.dependency("com.oplus.systemui.separate.OplusSeparateNotificationAndQSEx");
            Object view = call(ex, "getQSPanelView");
            if (view instanceof View) {
                behindPanel = (View) view;
                behindPanelAlpha = behindPanel.getAlpha();
                behindPanel.setAlpha(0f);
            }
        } catch (Throwable t) { log("hide QS panel behind overlay failed", t); }
    }

    static void restorePanelBehind() {
        if (behindPanel == null) return;
        try { behindPanel.setAlpha(behindPanelAlpha); } catch (Throwable ignored) { }
        behindPanel = null;
    }

    /**
     * Blur the panel behind the overlay with the native blur provider. One
     * pass is enough here: the overlay lives in the same window, so this
     * blurs exactly what is directly behind it and nothing twice.
     */
    static void applyBlurBackdrop(View view) {
        try {
            Class<?> smoothType = find("com.oplusos.systemui.common.view.SmoothCornersGradientDrawable");
            Object smooth = XposedHelpers.newInstance(smoothType);
            XposedHelpers.callMethod(smooth, "setColor", Integer.valueOf(0));
            Object provider = DetailShell.dependency("com.android.systemui.common.dialog.OplusQsDialogBlurBackgroundEx");
            Object drawable = call(provider, "provideBlurBackground", view, smooth, null, null);
            if (drawable instanceof android.graphics.drawable.Drawable)
                view.setBackground((android.graphics.drawable.Drawable) drawable);
        } catch (Throwable t) { log("overlay blur backdrop failed", t); }
    }

    static final class DetailShell {
        final Dialog dialog; final ViewGroup root; final ViewGroup frame; final TextView title;
        DetailShell(Dialog dialog, ViewGroup root, ViewGroup frame, TextView title) { this.dialog=dialog; this.root=root; this.frame=frame; this.title=title; }
        static DetailShell create() {
            try {
                Context c = context;
                int style = c.getResources().getIdentifier("OPlus.Theme.AlertDialog", "style", SYSTEMUI);
                int layout = c.getResources().getIdentifier("qs_detail", "layout", SYSTEMUI);
                Dialog dialog;
                ViewGroup root;
                if (style != 0 && layout != 0) {
                    Object manager = dependency("com.android.systemui.statusbar.phone.SystemUIDialogManager");
                    Object sysui = dependency("com.android.systemui.model.SysUiState");
                    Class<?> dialogType = find("com.oplus.systemui.common.dialog.OplusThemeSystemUiDialog");
                    dialog = (Dialog) XposedHelpers.newInstance(dialogType, c, Integer.valueOf(style), Float.valueOf(0.1f), manager, sysui);
                    Context dark = c;
                    try { dark = (Context) XposedHelpers.callStaticMethod(find("com.oplus.systemui.qs.base.util.QsColorUtil"), "createDarkColorContext$default", c); } catch (Throwable ignored) { }
                    root = (ViewGroup) LayoutInflater.from(dark).inflate(layout, null);
                    ViewGroup frame = (ViewGroup) field(root, "mDetailFrame");
                    TextView title = (TextView) field(root, "mQsDetailHeaderTitle");
                    frame.removeAllViews(); root.setVisibility(View.VISIBLE); dialog.setContentView(root);
                    root.setOnClickListener(v -> dialog.dismiss()); frame.setOnClickListener(v -> { });
                    dialog.setCancelable(true); dialog.setCanceledOnTouchOutside(true);
                    // No panel at all: let the dialog window blur whatever is
                    // behind it (we hide the QS panel while it is open), so the
                    // cards float directly on the blurred desktop like OplusX.
                    try {
                        if (dialog.getWindow() != null) {
                            dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
                            // The default dialog blur is the full system radius,
                            // which turns the already blurred panel into mush.
                            // A much smaller radius keeps the panel's colours
                            // readable while still hiding its tiles.
                            android.view.WindowManager.LayoutParams attrs = dialog.getWindow().getAttributes();
                            try { XposedHelpers.callMethod(attrs, "setBlurBehindRadius", Integer.valueOf(48)); }
                            catch (Throwable ignored) { }
                            dialog.getWindow().setAttributes(attrs);
                        }
                    } catch (Throwable t) { log("detail window background reset failed", t); }
                    frame.setBackground(null);
                    return new DetailShell(dialog, root, frame, title);
                }
            } catch (Throwable t) { log("native qs_detail shell unavailable", t); }
            try {
                Dialog dialog = new Dialog(context);
                LinearLayout root = new LinearLayout(context); root.setOrientation(LinearLayout.VERTICAL);
                TextView title = new TextView(context); title.setText(D1.LABEL); title.setTextSize(20); title.setPadding(dp(20),dp(16),dp(20),dp(8));
                root.addView(title, new LinearLayout.LayoutParams(-1, -2));
                FrameLayout frame = new FrameLayout(context); root.addView(frame, new LinearLayout.LayoutParams(-1, -2));
                dialog.setContentView(root); return new DetailShell(dialog, root, frame, title);
            } catch (Throwable t) { log("fallback detail shell unavailable", t); return null; }
        }
        static Object dependency(String name) throws Throwable {
            Class<?> dep = find("com.android.systemui.Dependency");
            Object service = XposedHelpers.getStaticObjectField(dep, "sDependency");
            return call(service, "getDependencyInner", find(name));
        }
        static int dp(int value) { return Math.round(value * context.getResources().getDisplayMetrics().density); }
    }
}
