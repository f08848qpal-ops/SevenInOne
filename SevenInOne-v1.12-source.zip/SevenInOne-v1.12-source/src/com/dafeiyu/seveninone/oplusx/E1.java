package com.dafeiyu.seveninone.oplusx;

/* JADX INFO: loaded from: classes.dex */
final class E1 {
    static final int a = 0;
    static final int b = 1;
    static final int c = 2;
    static final int d = 3;
    static final int e = 4;
    private boolean edit;
    private int epoch;
    private boolean open;

    E1() {
    }

    static int b(boolean z, boolean z2, int i) {
        return (z2 || (!z && i == 3)) ? 4 : 1;
    }

    static int c(boolean z, boolean z2, int i) {
        if (z) {
            return 4;
        }
        return (z2 || i == 3) ? 0 : 2;
    }

    boolean a(int i, int i2, int i3, int i4) {
        return d() && i == this.epoch && i2 >= 0 && i3 >= 0 && i2 < i4 && i3 < i4 && i2 != i3;
    }

    int click() {
        return (!this.open || this.edit) ? 0 : 1;
    }

    void close() {
        this.open = false;
        this.edit = false;
        this.epoch++;
    }

    boolean d() {
        return this.open && this.edit;
    }

    boolean e() {
        return this.open;
    }

    int epoch() {
        return this.epoch;
    }

    int f() {
        if (this.open) {
            return this.edit ? 3 : 2;
        }
        return 0;
    }

    void g() {
        if (this.open) {
            this.edit = !this.edit;
            this.epoch++;
        }
    }

    void open() {
        this.open = true;
        this.edit = false;
        this.epoch++;
    }
}
