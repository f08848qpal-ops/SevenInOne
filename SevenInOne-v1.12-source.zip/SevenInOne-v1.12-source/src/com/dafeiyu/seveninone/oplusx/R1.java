package com.dafeiyu.seveninone.oplusx;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import de.robv.android.xposed.XposedHelpers;
import java.util.ArrayList;
import java.util.List;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.function.Consumer;

/**
 * The OplusX-style 2x2 child compositor. It does not draw fake tile icons:
 * every child is a ColorOS OneXOne tile view backed by the real QSTile.
 */
final class R1 extends ViewGroup {
    private final ViewGroup outer;
    private final ViewGroup parent;
    private final View backgroundView;
    private final Z1.FakeTileHandler outerTile;
    private final ArrayList<View> hidden = new ArrayList<>();
    private final Map<View, Integer> originalVisibility = new IdentityHashMap<>();
    private final ArrayList<Slot> slots = new ArrayList<>();
    private final ArrayList<DetailTile> detailTiles = new ArrayList<>();
    private final ArrayList<NativeItem> detailItems = new ArrayList<>();
    private D1 shownConfig;
    private boolean attached;
    private boolean destroyed;
    private android.app.Dialog detailDialog;
    private View detailOverlay;
    private View detailContent;
    private View dialogDecor;
    private android.graphics.Rect tileRect;
    private android.graphics.Rect contentRect;
    /** First/last frame of the tile zoom, as a fraction of the 2x2 tile width.
     *  Smaller than 1 makes the page start slightly inside the tile. */
    private static final float TILE_ZOOM_START = 0.85f;
    private boolean suspended;
    private DetailTile longPressed;
    private android.view.View dialogView;
    private android.view.ViewGroup morphLayer;
    private MorphView morphView;
    private android.animation.ValueAnimator morphAnimator;
    private boolean dialogAttachedSeen;
    private android.graphics.Rect dialogRect;
    private android.graphics.Rect plateRect;

    R1(ViewGroup outer, Z1.FakeTileHandler outerTile) {
        super(outer.getContext());
        this.outer = outer;
        this.outerTile = outerTile;
        ViewGroup candidate = null;
        View bgView = null;
        try {
            Object bg = Z1.call(outer, "getBg");
            if (bg instanceof View) {
                bgView = (View) bg;
                if (bgView.getParent() instanceof ViewGroup) candidate = (ViewGroup) bgView.getParent();
            }
        } catch (Throwable ignored) { }
        this.parent = candidate == null ? outer : candidate;
        this.backgroundView = bgView;
        setClipChildren(false);
        setClipToPadding(false);
        setFocusable(true);
        setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
        setBackground(new ColorDrawable(Color.TRANSPARENT));
    }

    void attach() {
        if (attached || destroyed) return;
        attached = true;
        try {
            for (int i = 0; i < parent.getChildCount(); i++) {
                View child = parent.getChildAt(i);
                if (child != this && child != backgroundView && !hidden.contains(child)) {
                    hidden.add(child);
                    originalVisibility.put(child, child.getVisibility());
                    child.setVisibility(INVISIBLE);
                }
            }
            if (getParent() == null) parent.addView(this, new ViewGroup.LayoutParams(-1, -1));
            B8.e(outer, Z1.loader);
            refresh();
        } catch (Throwable t) { Z1.log("combo parent attach failed", t); }
    }

    void refresh() {
        if (destroyed) return;
        if (android.os.Looper.myLooper() != android.os.Looper.getMainLooper()) {
            Z1.MAIN.post(this::refresh); return;
        }
        boolean edit = isEditMode();
        if (!Z1.enabled() || edit) {
            B8.f(outer);
            setVisibility(GONE);
            try { B8.f(outer); } catch (Throwable ignored) { }
            restoreSiblings();
            closeDetail();
            return;
        }
        B8.e(outer, Z1.loader);
        setVisibility(VISIBLE);
        hideSiblings();
        // OplusX B8: the outer 2x2 must use the native media-panel outline as a
        // whole, otherwise liquid glass only follows the default small-tile path.
        try { B8.e(outer, Z1.loader); } catch (Throwable t) { Z1.log("2x2 panel outline unavailable", t); }
        D1 current = Z1.config();
        if (shownConfig == null || !shownConfig.equals(current)) rebuild(current);
        requestLayout();
        bringToFront();
    }

    @Override protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        if (visibility != VISIBLE && detailOverlay != null) closeDetail();
    }

    @Override protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (detailOverlay != null) closeDetail();
    }

    private boolean isEditMode() {
        try { return Boolean.TRUE.equals(Z1.call(outer, "isEditMode")); }
        catch (Throwable ignored) { return false; }
    }

    private void hideSiblings() {
        for (View view : hidden) if (view != null) view.setVisibility(INVISIBLE);
    }
    private void restoreSiblings() {
        for (View view : hidden) {
            if (view == null) continue;
            Integer visibility = originalVisibility.get(view);
            view.setVisibility(visibility == null ? VISIBLE : visibility.intValue());
        }
    }

    private void rebuild(D1 config) {
        for (Slot slot : slots) slot.close();
        slots.clear();
        removeAllViews();
        shownConfig = config;
        int count = Math.min(4, config.count);
        for (int slotIndex = 0; slotIndex < count; slotIndex++) {
            Slot slot = new Slot(slotIndex, config.isGroupSlot(slotIndex));
            int[] children = config.childrenForSlot(slotIndex);
            for (int childIndex : children) {
                if (childIndex >= 0 && childIndex < config.count && D1.valid(config.specs[childIndex])) {
                    NativeItem item = new NativeItem(config.specs[childIndex], false);
                    if (item.available()) slot.add(item);
                    else item.close();
                }
            }
            slot.installListeners();
            slots.add(slot);
            addView(slot, new LayoutParams(-1, -1));
        }
        // OplusX shows an empty fourth affordance for a three-item layout when
        // single-click expansion is selected; retain that behavior.
        if (config.count == 3 && !Z1.longPressExpand()) {
            Slot empty = new Slot(3, true);
            empty.setContentDescription("展开组合控件");
            empty.setOnClickListener(v -> expand());
            slots.add(empty);
            addView(empty, new LayoutParams(-1, -1));
        }
        setContentDescription("七合一，点击切换，长按展开");
    }

    @Override protected void onMeasure(int widthSpec, int heightSpec) {
        int width = MeasureSpec.getSize(widthSpec), height = MeasureSpec.getSize(heightSpec);
        setMeasuredDimension(width, height);
        int gap = dp(5), margin = dp(10);
        int cellW = Math.max(0, (width - margin * 2 - gap) / 2);
        int cellH = Math.max(0, (height - margin * 2 - gap) / 2);
        for (Slot slot : slots) {
            slot.measure(MeasureSpec.makeMeasureSpec(cellW, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(cellH, MeasureSpec.EXACTLY));
            int childW = Math.max(1, cellW / 2), childH = Math.max(1, cellH / 2);
            if (slot.getChildCount() == 1 && !slot.group) {
                int largeW = Math.round(cellW * 1.05f), largeH = Math.round(cellH * 1.05f);
                NativeItem item = (NativeItem) slot.getChildAt(0).getTag();
                if (item != null) item.setIconFactor(0.80f);
                slot.getChildAt(0).measure(MeasureSpec.makeMeasureSpec(largeW, MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(largeH, MeasureSpec.EXACTLY));
            } else {
                for (int i = 0; i < slot.getChildCount(); i++) {
                    NativeItem item = (NativeItem) slot.getChildAt(i).getTag();
                    if (item != null) item.setIconFactor(0.45f);
                    slot.getChildAt(i).measure(MeasureSpec.makeMeasureSpec(childW, MeasureSpec.EXACTLY),
                        MeasureSpec.makeMeasureSpec(childH, MeasureSpec.EXACTLY));
                }
            }
        }
    }

    @Override protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        int width = right - left, height = bottom - top;
        int gap = dp(5), margin = dp(10);
        int cellW = Math.max(0, (width - margin * 2 - gap) / 2);
        int cellH = Math.max(0, (height - margin * 2 - gap) / 2);
        for (int index = 0; index < slots.size(); index++) {
            Slot slot = slots.get(index);
            int x = margin + (index % 2) * (cellW + gap);
            int y = margin + (index / 2) * (cellH + gap);
            slot.layout(x, y, x + cellW, y + cellH);
            if (slot.getChildCount() == 1 && !slot.group) {
                int largeW = Math.round(cellW * 1.05f), largeH = Math.round(cellH * 1.05f);
                int x0 = (cellW - largeW) / 2, y0 = (cellH - largeH) / 2;
                slot.getChildAt(0).layout(x0, y0, x0 + largeW, y0 + largeH);
            } else {
                int childW = Math.max(1, cellW / 2), childH = Math.max(1, cellH / 2);
                for (int child = 0; child < slot.getChildCount(); child++) {
                    int cx = (child % 2) * childW, cy = (child / 2) * childH;
                    slot.getChildAt(child).layout(cx, cy, cx + childW, cy + childH);
                }
            }
        }
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    void outerAction(String action) {
        if (destroyed || !Z1.enabled()) return;
        expand();
    }

    private void expand() {
        if (detailDialog != null || detailOverlay != null || destroyed || isEditMode()) return;
        Z1.showDetail(this);
    }

    void populateDetail(ViewGroup frame, TextView title) {
        if (title != null) title.setText(D1.LABEL);
        D1 config = shownConfig == null ? Z1.config() : shownConfig;
        ArrayList<String> specs = new ArrayList<>();
        for (int i = 0; i < config.count; i++) {
            String spec = config.specs[i];
            if (!D1.valid(spec) || specs.contains(spec)) continue;
            specs.add(spec);
        }
        int total = specs.size();
        int limit = Math.min(total, 5);
        int gridEnd = 1 + ((limit - 1) / 2) * 2;
        LinearLayout content = new LinearLayout(getContext());
        content.setOrientation(LinearLayout.VERTICAL);
        content.setClipChildren(false);
        content.setClipToPadding(false);
        content.setPadding(dp(20), dp(6), dp(20), dp(18));
        if (total > 0) {
            content.addView(tile(specs, 0, gridEnd), new LinearLayout.LayoutParams(-1, dp(62)));
            int index = 1;
            while (index < gridEnd) {
                content.addView(spacer(16));
                SquareRow row = new SquareRow(getContext(), 22);
                for (int cell = 0; cell < 2 && index < gridEnd; cell++, index++) {
                    row.addView(tile(specs, index, gridEnd), new ViewGroup.LayoutParams(-1, -1));
                }
                content.addView(row, new LinearLayout.LayoutParams(-1, -2));
            }
            for (int i = gridEnd; i < total; i++) {
                content.addView(spacer(16));
                content.addView(tile(specs, i, gridEnd), new LinearLayout.LayoutParams(-1, dp(62)));
            }
        }
        frame.removeAllViews();
        frame.addView(content, new ViewGroup.LayoutParams(-1, -2));
    }

    private View tile(ArrayList<String> specs, int index, int gridEnd) {
        DetailTile tile = new DetailTile(specs.get(index), 2, index >= 1 && index < gridEnd ? 2 : 1);
        detailTiles.add(tile);
        if (!tile.available()) {
            View placeholder = new View(getContext());
            placeholder.setAlpha(0f);
            return placeholder;
        }
        return tile.view;
    }

    private View spacer(int height) {
        View view = new View(getContext());
        view.setLayoutParams(new LinearLayout.LayoutParams(1, dp(height)));
        return view;
    }

    private TextView label(String text) {
        TextView view = new TextView(getContext()); view.setText(text); view.setTextColor(Color.WHITE);
        view.setGravity(android.view.Gravity.CENTER); view.setTextSize(13); return view;
    }

    void closeDetail() {
        suspended = false;
        stopMorph();
        dialogRect = null;
        plateRect = null;
        setDialogAlpha(1f);
        restoreDialogDecor();
        if (detailOverlay != null) {
            final View overlay = detailOverlay; detailOverlay = null;
            overlay.setClickable(false);
            try { overlay.animate().cancel(); } catch (Throwable ignored) { }
            overlay.setScaleX(1f);
            overlay.setScaleY(1f);
            if (!playDetailExit(overlay)) {
                overlay.animate().alpha(0f).setDuration(140)
                    .setInterpolator(new android.view.animation.AccelerateInterpolator(1.2f))
                    .withEndAction(() -> {
                        try { if (overlay.getParent() instanceof ViewGroup) ((ViewGroup) overlay.getParent()).removeView(overlay); }
                        catch (Throwable ignored) { }
                        Z1.restorePanelBehind();
                        Z1.restoreQsContent();
                    }).start();
            }
        }
        if (detailDialog != null) {
            android.app.Dialog dialog = detailDialog; detailDialog = null;
            try { dialog.dismiss(); } catch (Throwable ignored) { }
        }
        for (DetailTile item : detailTiles) item.close();
        detailTiles.clear();
        for (NativeItem item : detailItems) item.close();
        detailItems.clear();
    }

    void setDetailDialog(android.app.Dialog dialog) { detailDialog = dialog; }
    void setDetailOverlay(View overlay) { detailOverlay = overlay; }
    void setDetailContent(View content) { detailContent = content; }
    void setDialogDecor(View decor) {
        dialogDecor = decor;
        if (decor == null) return;
        // Watchdog: the menu window must never stay invisible if the morph path
        // bails out before finishOpen().
        Z1.MAIN.postDelayed(() -> {
            if (dialogDecor == decor) {
                try { decor.setAlpha(1f); } catch (Throwable ignored) { }
                dialogDecor = null;
            }
        }, 1500);
    }

    private void restoreDialogDecor() {
        final View decor = dialogDecor;
        dialogDecor = null;
        if (decor != null) {
            try { decor.setAlpha(1f); } catch (Throwable ignored) { }
        }
    }

    /** Snapshot the 2x2 surface position before the QS content is hidden. */
    void prepareTileRect() { tileRect = boundsOf(this); }

    /** Grow the page out of the 2x2 tile: same surface, so it scales from the
     *  tile rect into the final page rect instead of fading in place. */
    void playDetailEnter(final View content) {
        if (content == null) return;
        detailContent = content;
        final android.graphics.Rect tile = tileRect != null ? tileRect : boundsOf(this);
        if (tile == null || tile.width() <= 0 || tile.height() <= 0) {
            content.setAlpha(1f);
            return;
        }
        startDetailEnter(content, tile, 0);
    }

    /** The page is not measured on the first frame; retry briefly before
     *  giving up so the zoom always starts from a real rect. */
    private void startDetailEnter(final View content, final android.graphics.Rect tile, final int attempt) {
        if (content == null) return;
        content.post(() -> {
            try {
                android.graphics.Rect base = boundsOf(content);
                if (base == null || base.width() <= 0 || base.height() <= 0) {
                    if (attempt < 5) {
                        Z1.MAIN.postDelayed(() -> startDetailEnter(content, tile, attempt + 1), 16);
                    } else {
                        content.setAlpha(1f);
                    }
                    return;
                }
                contentRect = base;
                float scale = tile.width() / (float) base.width() * TILE_ZOOM_START;
                content.setPivotX(base.width() / 2f);
                content.setPivotY(base.height() / 2f);
                content.setScaleX(scale);
                content.setScaleY(scale);
                content.setTranslationX(tile.centerX() - base.centerX());
                content.setTranslationY(tile.centerY() - base.centerY());
                // Reveal only after the first frame is already at tile size:
                // the first frames dissolve in, the rest is pure scaling.
                content.setAlpha(0f);
                content.animate()
                    .scaleX(1f).scaleY(1f)
                    .translationX(0f).translationY(0f)
                    .setDuration(280)
                    .setInterpolator(new android.view.animation.DecelerateInterpolator(1.3f))
                    .start();
                android.animation.ObjectAnimator enterFade =
                    android.animation.ObjectAnimator.ofFloat(content, "alpha", 0f, 1f);
                enterFade.setDuration(190);
                enterFade.setInterpolator(new android.view.animation.DecelerateInterpolator(1.6f));
                enterFade.start();
                Z1.log("detail enter zoom " + tile.toShortString() + " -> " + base.toShortString());
            } catch (Throwable t) {
                Z1.log("detail enter zoom failed", t);
                content.setAlpha(1f);
            }
        });
    }

    /** Shrink the page back into the 2x2 tile. Returns false when the geometry
     *  is unavailable, so the caller can fall back to a plain fade. */
    private boolean playDetailExit(final View overlay) {
        final View content = detailContent;
        final android.graphics.Rect tile = tileRect;
        final android.graphics.Rect base = contentRect;
        if (content == null || tile == null || base == null || base.width() <= 0) return false;
        detailContent = null;
        tileRect = null;
        contentRect = null;
        try { content.animate().cancel(); } catch (Throwable ignored) { }
        float scale = tile.width() / (float) base.width() * TILE_ZOOM_START;
        // Exact mirror of playDetailEnter: same duration, same start alpha and
        // the time-reversed easing curve.
        content.animate()
            .scaleX(scale).scaleY(scale)
            .translationX(tile.centerX() - base.centerX())
            .translationY(tile.centerY() - base.centerY())
            .setDuration(280)
            .setInterpolator(new android.view.animation.AccelerateInterpolator(1.3f))
            .withEndAction(() -> {
                try {
                    if (overlay.getParent() instanceof ViewGroup)
                        ((ViewGroup) overlay.getParent()).removeView(overlay);
                } catch (Throwable ignored) { }
                Z1.restorePanelBehind();
                Z1.restoreQsContent();
            }).start();
        // Stay opaque while shrinking, then dissolve over the last frames while
        // the control centre fades back in underneath it.
        float fromAlpha = content.getAlpha() <= 0.01f ? 1f : content.getAlpha();
        android.animation.ObjectAnimator exitFade =
            android.animation.ObjectAnimator.ofFloat(content, "alpha", fromAlpha, 0f);
        exitFade.setStartDelay(185);
        exitFade.setDuration(95);
        exitFade.setInterpolator(new android.view.animation.AccelerateInterpolator(1.0f));
        exitFade.start();
        Z1.restoreQsContentAnimated(175, 105);
        return true;
    }
    boolean hasDetail() { return detailOverlay != null; }
    boolean isSuspended() { return suspended; }

    /** Step aside for a tile's own detail menu without tearing the page down:
     *  the QS content stays hidden and the cards stay alive. The round plate of
     *  the pressed card morphs into the menu panel while the menu fades in. */
    void suspendDetail() {
        if (detailOverlay == null || suspended) return;
        suspended = true;
        final View overlay = detailOverlay;
        overlay.setClickable(false);
        final DetailTile pressed = longPressed;
        if (pressed != null) {
            android.graphics.Rect rect = boundsOf(pressed.iconBox != null ? (View) pressed.iconBox : pressed.view);
            if (rect != null) {
                plateRect = rect;
                Z1.log("detail from " + pressed.spec + " plate=" + rect.toShortString());
            }
        }
        // The long press was dispatched with the plate as its Expandable
        // anchor, so SystemUI itself plays the plate -> detail transition.
        // We only fade the page out of the way and keep watching for close.
        overlay.setAlpha(1f);
        overlay.setScaleX(1f);
        overlay.setScaleY(1f);
        if (detailContent != null) {
            try { detailContent.animate().cancel(); } catch (Throwable ignored) { }
            detailContent.setScaleX(1f);
            detailContent.setScaleY(1f);
            detailContent.setTranslationX(0f);
            detailContent.setTranslationY(0f);
            detailContent.setAlpha(1f);
        }
        for (DetailTile item : detailTiles) {
            if (item.view != null) {
                try { item.view.animate().cancel(); } catch (Throwable ignored) { }
                item.view.setScaleX(1f);
                item.view.setScaleY(1f);
            }
        }
        overlay.animate().alpha(0f).setDuration(120)
            .setInterpolator(new android.view.animation.LinearInterpolator())
            .withEndAction(() -> {
                if (suspended && detailOverlay == overlay) {
                    overlay.setAlpha(0f);
                    overlay.setVisibility(View.INVISIBLE);
                }
            }).start();
        Z1.MAIN.postDelayed(() -> watchFirstPanel(overlay, 0), 60);
    }

    private void watchFirstPanel(final View overlay, final int attempt) {
        if (!suspended || detailOverlay != overlay) return;
        View panel = findViewDialog(overlay.getRootView());
        if (panel != null) {
            final View settledPanel = panel;
            android.graphics.Rect rect = boundsOf(panel);
            if (rect != null && rect.width() > 0) dialogRect = rect;
            watchDetailPanel(panel);
            Z1.MAIN.postDelayed(() -> {
                if (!suspended) return;
                android.graphics.Rect settled = boundsOf(settledPanel);
                if (settled != null && settled.width() > 0) {
                    dialogRect = settled;
                    Z1.log("menu rect settled " + settled.toShortString());
                }
            }, 360);
            return;
        }
        if (attempt < 40) {
            Z1.MAIN.postDelayed(() -> watchFirstPanel(overlay, attempt + 1), 50);
        } else {
            Z1.log("detail panel not found for close watch");
        }
    }

    /** The native menu is a view-dialog and attaches a few frames after
     * showDialog(). Wait for a laid-out, settled panel before measuring it. */
    private void awaitMenuPanel(final View overlay, final android.graphics.Rect source, final int attempt) {
        if (!suspended || detailOverlay != overlay) return;
        View panel = findViewDialog(overlay.getRootView());
        if (panel == null) {
            if (attempt < 20) {
                Z1.MAIN.postDelayed(() -> awaitMenuPanel(overlay, source, attempt + 1), 25);
                return;
            }
            Z1.log("detail menu frame missing, plain native handover");
            finishOpen(overlay);
            return;
        }
        cancelDialogAnimations(panel, overlay.getRootView());
        android.graphics.Rect target = boundsOf(panel);
        if (target == null || target.width() <= 0 || target.height() <= 0) {
            if (attempt < 20) {
                Z1.MAIN.postDelayed(() -> awaitMenuPanel(overlay, source, attempt + 1), 25);
                return;
            }
            Z1.log("detail menu bounds missing, plain native handover");
            finishOpen(overlay);
            return;
        }
        dialogView = panel;
        dialogAttachedSeen = false;
        dialogRect = new android.graphics.Rect(target);
        setDialogAlpha(0f);
        Z1.log("detail frame morph " + panel.getClass().getSimpleName() + " "
            + target.toShortString() + " from " + source.toShortString());
        android.graphics.Rect to = toRoot(overlay.getRootView(), target);
        if (morphView == null || to == null) {
            finishOpen(overlay);
            return;
        }
        morphView.setTarget(to, Math.min(dp(28), Math.min(to.width(), to.height()) / 2f));
        watchDetailPanel(panel);
        animateMorph(280, () -> finishOpen(overlay));
    }

    /** The native menu is a Dialog window; dismissing it does not always run a
     *  hook we own. Detach plus a light poll guarantees the return morph fires. */
    private void watchDetailPanel(final View panel) {
        if (panel == null) return;
        panel.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            @Override public void onViewAttachedToWindow(View view) { dialogAttachedSeen = true; }
            @Override public void onViewDetachedFromWindow(View view) {
                Z1.log("detail panel detached");
                Z1.MAIN.postDelayed(R1.this::resumeDetail, 60);
            }
        });
        if (panel.getParent() != null && panel.isShown()) dialogAttachedSeen = true;
        pollDetailPanel(panel, 0);
    }

    private void pollDetailPanel(final View panel, final int tick) {
        if (!suspended || detailOverlay == null) return;
        if (dialogAttachedSeen && (panel.getParent() == null || !panel.isShown())) {
            Z1.log("detail panel gone, resume");
            resumeDetail();
            return;
        }
        if (tick < 900) Z1.MAIN.postDelayed(() -> pollDetailPanel(panel, tick + 1), 100);
    }

    private void finishOpen(final View overlay) {
        setDialogAlpha(1f);
        restoreDialogDecor();
        stopMorph();
        if (overlay != null && suspended) {
            overlay.animate().cancel();
            overlay.setAlpha(0f);
            overlay.setScaleX(1f);
            overlay.setScaleY(1f);
            overlay.setVisibility(View.INVISIBLE);
            overlay.setClickable(false);
        }
    }

    private void hideOverlayNow(final View overlay) {
        if (overlay == null) return;
        try { overlay.animate().cancel(); } catch (Throwable ignored) { }
        overlay.setAlpha(0f);
        overlay.setScaleX(1f);
        overlay.setScaleY(1f);
        overlay.setVisibility(View.INVISIBLE);
    }

    /** Soft exit for the seven-in-one page: plain alpha fade, no scale and no
     *  translation, so it never competes with the plate morph above it. */
    private void fadeOverlayOut(final View overlay) {
        if (overlay == null) return;
        try { overlay.animate().cancel(); } catch (Throwable ignored) { }
        overlay.setScaleX(1f);
        overlay.setScaleY(1f);
        overlay.setAlpha(1f);
        overlay.animate().alpha(0f).setDuration(170)
            .setInterpolator(new android.view.animation.LinearInterpolator())
            .withEndAction(() -> {
                if (suspended && detailOverlay == overlay) {
                    overlay.setAlpha(0f);
                    overlay.setVisibility(View.INVISIBLE);
                }
            }).start();
    }

    /** Return from the native menu: the menu surface contracts back into the
     * pressed plate while the seven-in-one page fades in. */
    void resumeDetail() {
        if (detailOverlay == null || !suspended) return;
        suspended = false;
        final View overlay = detailOverlay;
        overlay.setVisibility(View.VISIBLE);
        DetailTile tile = longPressed;
        final View plate = tile == null ? null : tile.iconBox;
        final android.graphics.Rect source = plateRect != null ? plateRect : boundsOf(plate);
        android.graphics.Rect panelRect = dialogRect;
        if (panelRect != null) {
            View rootView = overlay.getRootView();
            int rootWidth = rootView == null ? 0 : rootView.getWidth();
            if (rootWidth > 0 && (panelRect.left < 0 || panelRect.right > rootWidth)) {
                int width = panelRect.width();
                int left = (rootWidth - width) / 2;
                panelRect = new android.graphics.Rect(left, panelRect.top, left + width, panelRect.bottom);
                Z1.log("menu rect recentered " + panelRect.toShortString());
            }
        }
        final android.graphics.Rect fromPanel = panelRect;
        Z1.ensureQsHidden();
        Z1.MAIN.postDelayed(Z1::ensureQsHidden, 260);
        if (tile == null || plate == null || source == null || fromPanel == null
                || fromPanel.width() <= 0 || fromPanel.height() <= 0) {
            overlay.setAlpha(1f);
            overlay.setScaleX(1f);
            overlay.setScaleY(1f);
            overlay.setClickable(true);
            if (plate != null) plate.setAlpha(1f);
            dialogRect = null;
            Z1.log("resume page visible, no morph");
            return;
        }
        try {
            // Mirror of the plate -> menu transition: the menu surface shrinks
            // back into the pressed plate while the page fades back in.
            Z1.log("resume morph " + fromPanel.toShortString() + " -> " + source.toShortString());
            overlay.setAlpha(0f);
            overlay.setClickable(false);
            plate.setAlpha(0f);
            buildMorph(overlay, fromPanel,
                Math.min(dp(28), Math.min(fromPanel.width(), fromPanel.height()) / 2f),
                morphColor(tile), null);
            if (morphView != null) morphView.setFadeWithProgress(true);
            android.graphics.Rect to = toRoot(overlay.getRootView(), source);
            if (morphView == null || to == null) throw new IllegalStateException("morph layer unavailable");
            morphView.setTarget(to, circleRadius(source));
            overlay.animate().alpha(1f).setStartDelay(60).setDuration(180)
                .setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
            animateMorph(240, () -> {
                stopMorph();
                plate.setAlpha(1f);
                overlay.setAlpha(1f);
                overlay.setClickable(true);
                dialogRect = null;
            });
        } catch (Throwable t) {
            Z1.log("resume morph failed", t);
            stopMorph();
            plate.setAlpha(1f);
            overlay.setAlpha(1f);
            overlay.setClickable(true);
            dialogRect = null;
        }
    }

    private int morphColor(DetailTile tile) {
        int color = 0x26FFFFFF;
        try { if (tile != null && tile.plate != null) color = tile.plate.color(); }
        catch (Throwable ignored) { }
        // The active plate is opaque; keep the transition surface translucent.
        if (Color.alpha(color) == 255) color = (color & 0x00FFFFFF) | 0x66000000;
        return color;
    }

    private float circleRadius(android.graphics.Rect rect) {
        return rect == null ? 0f : Math.min(rect.width(), rect.height()) / 2f;
    }

    private android.graphics.Bitmap plateGlyph(DetailTile tile) {
        try { return tile == null ? null : snapshot(tile.iconView); }
        catch (Throwable ignored) { return null; }
    }

    /** Add a full-window, non-interactive layer and park a clean round shape at
     * the source rect. It is not a stretched plate bitmap. */
    private void buildMorph(View anchor, android.graphics.Rect fromScreen, float radius,
                            int color, android.graphics.Bitmap glyph) {
        stopMorph();
        View root = anchor == null ? null : anchor.getRootView();
        if (!(root instanceof ViewGroup) || fromScreen == null) return;
        android.graphics.Rect from = toRoot(root, fromScreen);
        if (from == null) return;
        ViewGroup host = (ViewGroup) root;
        FrameLayout layer = new FrameLayout(getContext());
        layer.setClipChildren(false);
        layer.setClipToPadding(false);
        layer.setClickable(false);
        layer.setFocusable(false);
        MorphView view = new MorphView(getContext());
        layer.addView(view, new FrameLayout.LayoutParams(-1, -1));
        host.addView(layer, new ViewGroup.LayoutParams(-1, -1));
        host.bringChildToFront(layer);
        try { XposedHelpers.callMethod(layer, "setTranslationZ", Float.valueOf(3000f)); }
        catch (Throwable ignored) { }
        view.begin(from, radius, color, glyph);
        morphLayer = layer;
        morphView = view;
    }

    /** Screen rect -> root-local rect. The shade window is not assumed to be
     * located at screen origin. */
    private android.graphics.Rect toRoot(View root, android.graphics.Rect screen) {
        if (root == null || screen == null) return null;
        try {
            int[] location = new int[2];
            root.getLocationOnScreen(location);
            return new android.graphics.Rect(screen.left - location[0], screen.top - location[1],
                screen.right - location[0], screen.bottom - location[1]);
        } catch (Throwable t) { return new android.graphics.Rect(screen); }
    }

    private void animateMorph(int duration, final Runnable end) {
        if (morphView == null) { if (end != null) end.run(); return; }
        if (morphAnimator != null) {
            android.animation.ValueAnimator old = morphAnimator;
            morphAnimator = null;
            try { old.cancel(); } catch (Throwable ignored) { }
        }
        final android.animation.ValueAnimator animator = android.animation.ValueAnimator.ofFloat(0f, 1f);
        morphAnimator = animator;
        animator.setDuration(duration);
        animator.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());
        animator.addUpdateListener(a -> {
            if (morphView != null) morphView.setProgress(((Float) a.getAnimatedValue()).floatValue());
        });
        animator.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator animation) {
                if (morphAnimator != animator) return;
                morphAnimator = null;
                if (end != null) end.run();
            }
        });
        animator.start();
    }

    private void stopMorph() {
        if (morphAnimator != null) {
            android.animation.ValueAnimator old = morphAnimator;
            morphAnimator = null;
            try { old.cancel(); } catch (Throwable ignored) { }
        }
        if (morphLayer != null) {
            try {
                if (morphLayer.getParent() instanceof ViewGroup)
                    ((ViewGroup) morphLayer.getParent()).removeView(morphLayer);
            } catch (Throwable ignored) { }
        }
        morphLayer = null;
        morphView = null;
    }

    private android.graphics.Rect boundsOf(View view) {
        if (view == null || view.getWidth() <= 0 || view.getHeight() <= 0) return null;
        int[] location = new int[2];
        view.getLocationOnScreen(location);
        return new android.graphics.Rect(location[0], location[1],
            location[0] + view.getWidth(), location[1] + view.getHeight());
    }

    private android.graphics.Bitmap snapshot(View view) {
        try {
            if (view == null || view.getWidth() <= 0 || view.getHeight() <= 0) return null;
            android.graphics.Bitmap bitmap = android.graphics.Bitmap.createBitmap(
                view.getWidth(), view.getHeight(), android.graphics.Bitmap.Config.ARGB_8888);
            view.draw(new android.graphics.Canvas(bitmap));
            return bitmap;
        } catch (Throwable t) {
            Z1.log("detail morph snapshot failed", t);
            return null;
        }
    }

    private void setDialogAlpha(float alpha) {
        if (dialogView == null) return;
        try { dialogView.setAlpha(alpha); } catch (Throwable ignored) { }
    }

    private View findViewDialog(View root) {
        if (root == null) return null;
        try {
            // OplusQSDetail.mDetailFrame on this ROM: 2131362831 / 0x7f0a040f.
            View frame = root.findViewById(0x7f0a040f);
            if (isDetailFrame(frame, root)) return frame;
            View detail = root.findViewById(0x7f0a0b75);
            if (detail instanceof ViewGroup) {
                frame = detail.findViewById(0x7f0a040f);
                if (isDetailFrame(frame, root)) return frame;
            }
            View host = root.findViewById(0x7f0a104e);
            if (host instanceof ViewGroup) {
                frame = host.findViewById(0x7f0a040f);
                if (isDetailFrame(frame, root)) return frame;
            }
        } catch (Throwable t) { Z1.log("detail frame lookup failed", t); }
        return null;
    }

    private boolean isDetailFrame(View view, View root) {
        if (view == null || view.getId() != 0x7f0a040f || view.getVisibility() != View.VISIBLE) return false;
        if (view.getWidth() <= 0 || view.getHeight() <= 0) return false;
        // Refuse the SysUIViewDialogFrameLayout/OplusQSDetail full-screen wrapper.
        if (root != null && root.getWidth() > 0 && root.getHeight() > 0
                && view.getWidth() >= root.getWidth() * 0.98f
                && view.getHeight() >= root.getHeight() * 0.98f) return false;
        return true;
    }

    /** Stop the ROM's detail pop transform before measuring the real frame. */
    private void cancelDialogAnimations(View panel, View root) {
        if (panel == null) return;
        View host = root == null ? null : root.findViewById(0x7f0a104e);
        View current = panel;
        for (int i = 0; current != null && i < 12; i++) {
            if (current == root || current == dialogDecor) break;
            try {
                current.animate().cancel();
                current.clearAnimation();
                current.setScaleX(1f);
                current.setScaleY(1f);
                current.setTranslationX(0f);
                current.setTranslationY(0f);
                current.setRotation(0f);
                current.setAlpha(1f);
            } catch (Throwable ignored) { }
            if (current == host) break;
            android.view.ViewParent parent = current.getParent();
            current = parent instanceof View ? (View) parent : null;
        }
    }

    void destroy() {
        if (destroyed) return; destroyed = true;
        B8.f(outer);
        closeDetail();
        for (Slot slot : slots) slot.close(); slots.clear();
        removeAllViews(); restoreSiblings(); hidden.clear(); originalVisibility.clear();
        try { B8.f(outer); } catch (Throwable ignored) { }
        if (getParent() instanceof ViewGroup) ((ViewGroup) getParent()).removeView(this);
    }

    private void bindCompactTree(View view, final NativeItem item, final boolean detailOnLong) {
        view.setClickable(true);
        view.setOnClickListener(v -> {
            if (item == null || item.handle == null) return;
            if (item.spec == null) return;
            item.handle.click(item.compactView);
        });
        view.setOnLongClickListener(v -> {
            if (item == null || item.handle == null) return true;
            if (detailOnLong) item.handle.detail(item.compactView); else expand();
            return true;
        });
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) bindCompactTree(group.getChildAt(i), item, detailOnLong);
        }
    }

    final class Slot extends FrameLayout {
        final int index; final boolean group;
        Slot(int index, boolean group) { super(R1.this.getContext()); this.index = index; this.group = group; setClipChildren(false); setClipToPadding(false); setFocusable(true); }
        void add(NativeItem item) {
            addView(item.compactView);
            // Slots 0..2 are the three large tiles: long press opens that
            // tile's own native detail. The grouped fourth slot opens combo.
            bindCompactTree(item.compactView, item, !group && index < 3);
        }
        void installListeners() {
            setClickable(true); setFocusable(true);
            setOnClickListener(v -> {
                if (group) expand();
                else if (getChildCount() > 0) childAt(0).handle.click(childAt(0).compactView);
            });
            setOnLongClickListener(v -> {
                if (group || index >= 3) { expand(); return true; }
                if (getChildCount() > 0) childAt(0).handle.detail(childAt(0).compactView);
                return true;
            });
        }
        NativeItem childAt(int i) { return (NativeItem) getChildAt(i).getTag(); }

        /** Press feedback copied from the control-centre round tiles: the cell
         *  under the finger shrinks, then springs back on release. */
        private View pressed;
        private float pressedX, pressedY;

        @Override public boolean dispatchTouchEvent(android.view.MotionEvent event) {
            switch (event.getAction()) {
                case android.view.MotionEvent.ACTION_DOWN:
                    pressed = cellAt(event.getX(), event.getY());
                    if (pressed != null) {
                        pressedX = pressed.getScaleX();
                        pressedY = pressed.getScaleY();
                        pressed.animate().cancel();
                        pressed.animate().scaleX(0.88f).scaleY(0.88f).setDuration(90)
                            .setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
                    }
                    break;
                case android.view.MotionEvent.ACTION_UP:
                case android.view.MotionEvent.ACTION_CANCEL:
                    if (pressed != null) {
                        View cell = pressed; pressed = null;
                        cell.animate().cancel();
                        cell.animate().scaleX(pressedX).scaleY(pressedY).setDuration(220)
                            .setInterpolator(new android.view.animation.OvershootInterpolator(1.4f)).start();
                    }
                    break;
                default:
                    break;
            }
            return super.dispatchTouchEvent(event);
        }

        private View cellAt(float x, float y) {
            for (int i = 0; i < getChildCount(); i++) {
                View child = getChildAt(i);
                if (x >= child.getLeft() && x <= child.getRight() && y >= child.getTop() && y <= child.getBottom())
                    return child;
            }
            return getChildCount() > 0 ? getChildAt(0) : null;
        }

        void close() {
            for (int i = 0; i < getChildCount(); i++) {
                Object tag = getChildAt(i).getTag(); if (tag instanceof NativeItem) ((NativeItem) tag).close();
            }
            removeAllViews();
        }
    }

    /** Circle surface with the real native OplusQSIconView as its child. */
    final class BareIconView extends android.widget.FrameLayout {
        private final String spec;
        private final android.graphics.Paint paint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private Object state;
        private float iconFactor = 1f;
        BareIconView(String spec, View iconView) {
            super(R1.this.getContext());
            this.spec = spec;
            setWillNotDraw(false);
            setClipChildren(false);
            setClipToPadding(false);
            addView(iconView, new android.widget.FrameLayout.LayoutParams(-1, -1));
            tintWhite(iconView);
        }
        private void tintWhite(android.view.View view) {
            if (view == null) return;
            if (view instanceof android.widget.ImageView) {
                ((android.widget.ImageView) view).setColorFilter(android.graphics.Color.WHITE, android.graphics.PorterDuff.Mode.SRC_IN);
            }
            android.graphics.drawable.Drawable background = view.getBackground();
            if (background != null) {
                try { background.setColorFilter(android.graphics.Color.WHITE, android.graphics.PorterDuff.Mode.SRC_IN); } catch (Throwable ignored) { }
            }
            if (view instanceof android.view.ViewGroup) {
                android.view.ViewGroup group = (android.view.ViewGroup) view;
                for (int i = 0; i < group.getChildCount(); i++) tintWhite(group.getChildAt(i));
            }
        }
        void setIconFactor(float factor) {
            iconFactor = factor;
            if (getChildCount() > 0) {
                getChildAt(0).setScaleX(factor);
                getChildAt(0).setScaleY(factor);
            }
            invalidate();
        }
        void accept(Object value) { state = value; invalidate(); }
        private int activeColor() {
            if (spec != null) {
                if (spec.equals("cell") || spec.equals("hotspot")) return 0xFF22C55E;
                if (spec.equals("bt")) return 0xFF6B7280;
                if (spec.equals("wifi") || spec.equals("airplane")
                    || spec.equals("location") || spec.equals("oshare")) return 0xFF3B82F6;
            }
            return 0xFF3B82F6;
        }
        @Override protected void onDraw(android.graphics.Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth(), h = getHeight();
            float cx = w / 2f, cy = h / 2f;
            float radius = Math.min(w, h) * 0.40f;
            boolean active = Z1.numberField(state, "state") == 2;
            paint.setStyle(android.graphics.Paint.Style.FILL);
            paint.setColor(active ? activeColor() : 0x66FFFFFF);
            canvas.drawCircle(cx, cy, radius, paint);
        }
    }

    /** Two square cells per row, sized from the measured width. */
    final class SquareRow extends android.view.ViewGroup {
        private final int gap;
        SquareRow(android.content.Context context, int gapDp) { super(context); this.gap = dp(gapDp); }
        @Override protected void onMeasure(int widthSpec, int heightSpec) {
            int width = MeasureSpec.getSize(widthSpec);
            int cell = Math.max(0, (width - gap) / 2);
            setMeasuredDimension(width, cell);
            for (int i = 0; i < getChildCount(); i++) {
                getChildAt(i).measure(MeasureSpec.makeMeasureSpec(cell, MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(cell, MeasureSpec.EXACTLY));
            }
        }
        @Override protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
            int width = right - left;
            int cell = Math.max(0, (width - gap) / 2);
            for (int i = 0; i < getChildCount(); i++) {
                int x = i * (cell + gap);
                getChildAt(i).layout(x, 0, x + cell, cell);
            }
        }
    }

    /**
     * One native QS tile view used as a card on the second level page. The
     * 2x1 pill and 2x2 square are the real Oplus tile views, so the surface,
     * icon, label and liquid glass all come from the system itself.
     */
    final class DetailTile {
        final String spec;
        final Z1.TileHandle handle;
        View view;
        TextView label;
        TextView secondary;
        ChevronView chevron;
        FrameLayout iconBox;
        PlateView plate;
        View surface;
        View iconView;
        View highlight;
        int highlightVisibility = View.VISIBLE;
        boolean closed;

        DetailTile(String spec, int columns, int rows) {
            this.spec = spec;
            this.handle = Z1.acquire(spec);
            if (handle != null) {
                try { view = create(columns, rows); }
                catch (Throwable t) { Z1.log("native detail tile failed: " + spec, t); }
            }
            if (handle == null || view == null) {
                if (handle != null) handle.close();
                return;
            }
            try { applyLabels(Z1.copyState(Z1.call(handle.tile(), "getState"))); }
            catch (Throwable ignored) { }
            try {
                final View shell = view;
                handle.start(state -> Z1.MAIN.post(() -> {
                    if (closed) return;
                    try { Z1.call(tileView(shell), "onStateChanged", neutral(state)); } catch (Throwable ignored) { }
                    applyLabels(state);
                }));
            } catch (Throwable t) { Z1.log("detail tile state failed: " + spec, t); }
        }

        private View create(int columns, int rows) throws Throwable {
            Class<?> iconType = Z1.find("com.oplus.systemui.plugins.qs.customize.view.tile.OplusQSIconView");
            Class<?> labelType = Z1.find("com.oplus.systemui.plugins.qs.customize.view.tile.QsLabelView");
            Class<?> tileType = Z1.find(rows >= 2
                ? "com.oplus.systemui.plugins.qs.customize.view.tile.OplusQSResizeableTileViewTwoXTwo"
                : "com.oplus.systemui.plugins.qs.customize.view.tile.OplusQSResizeableTileViewTwoXOne");
            Object icon = XposedHelpers.newInstance(iconType, getContext(), Z1.span(columns, rows), Boolean.FALSE);
            Object nativeLabel = XposedHelpers.newInstance(labelType, getContext());
            try { Z1.call(nativeLabel, "setEnableExpandIndicator", Boolean.FALSE); } catch (Throwable ignored) { }
            Object tileView = XposedHelpers.newInstance(tileType, getContext(), icon, nativeLabel);
            Z1.call(tileView, "init", handle.tile());
            View tile = (View) tileView;
            try {
                Object size = Z1.span(columns, rows);
                java.util.List<Object> sizes = java.util.Collections.singletonList(size);
                Z1.call(tile, "onOutlineUpdate", sizes);
                Z1.call(tile, "onDrawableUpdate", sizes, Boolean.FALSE);
                Z1.call(tile, "onDrawableUpdate", sizes, Boolean.TRUE);
            } catch (Throwable t) { Z1.log("detail tile outline failed: " + spec, t); }
            try { B8.e(tile, Z1.loader); }
            catch (Throwable t) { Z1.log("detail tile panel outline failed: " + spec, t); }
            // iOS style long cards are fully rounded pills; the media panel
            // outline is only a small rounded rectangle.
            if (rows < 2) {
                try {
                    Object transition = Z1.call(tile, "getTransitionDrawable");
                    Object pill = XposedHelpers.newInstance(
                        Z1.find("com.oplusos.systemui.common.outline.RoundRectOutlineProvider"),
                        Float.valueOf(999f), null);
                    Z1.call(transition, "setBlockPathProvider", pill);
                    java.util.List<Object> sizes = java.util.Collections.singletonList(Z1.span(columns, rows));
                    Z1.call(tile, "onOutlineUpdate", sizes);
                    Z1.call(tile, "onDrawableUpdate", sizes, Boolean.FALSE);
                    Z1.call(tile, "onDrawableUpdate", sizes, Boolean.TRUE);
                } catch (Throwable t) { Z1.log("pill outline failed: " + spec, t); }
            }
            try { Z1.call(tile, "setStateImmediately", neutral(Z1.copyState(Z1.call(handle.tile(), "getState")))); }
            catch (Throwable ignored) { }
            View bg = null;
            try {
                Object value = Z1.call(tile, "getBg");
                if (value instanceof View) bg = (View) value;
            } catch (Throwable ignored) { }
            surface = bg;
            View iconView = null;
            try {
                Object value = Z1.call(tile, "getIconView");
                if (value instanceof View) iconView = (View) value;
            } catch (Throwable t) { Z1.log("detail icon lookup failed: " + spec, t); }
            if (iconView != null && iconView.getParent() instanceof ViewGroup)
                ((ViewGroup) iconView.getParent()).removeView(iconView);
            this.iconView = iconView;
            if (tile instanceof ViewGroup) {
                ViewGroup group = (ViewGroup) tile;
                for (int i = 0; i < group.getChildCount(); i++) {
                    View child = group.getChildAt(i);
                    String name = child.getClass().getSimpleName();
                    // Keep every layer that paints the card (background image
                    // views), drop only the text/button strip.
                    if (name.contains("Button") || name.contains("Label"))
                        child.setVisibility(View.GONE);
                }
            }
            try {
                // TwoXOne keeps its label container at 2131363622, TwoXTwo
                // reassigns it to 2131363623.
                View labelContainer = tile.findViewById(2131363622);
                if (labelContainer != null) labelContainer.setVisibility(View.GONE);
                View labelContainer2 = tile.findViewById(2131363623);
                if (labelContainer2 != null) labelContainer2.setVisibility(View.GONE);
            } catch (Throwable ignored) { }
            if (tile instanceof ViewGroup) {
                ViewGroup group = (ViewGroup) tile;
                for (int i = group.getChildCount() - 1; i >= 0; i--) {
                    View child = group.getChildAt(i);
                    if (child instanceof android.widget.ImageView && child != bg) {
                        highlight = child;
                        highlightVisibility = child.getVisibility();
                        break;
                    }
                }
            }
            tile.setClickable(false);
            tile.setFocusable(false);
            FrameLayout shell = new FrameLayout(getContext());
            shell.setClickable(true);
            shell.setFocusable(true);
            shell.setOnClickListener(v -> { if (handle != null) handle.click(shell); });
            shell.setOnLongClickListener(v -> beginDetail());
            shell.addView(tile, new FrameLayout.LayoutParams(-1, -1));
            View touch = new View(getContext());
            touch.setClickable(true);
            touch.setFocusable(false);
            touch.setOnClickListener(v -> { if (handle != null) handle.click(v); });
            touch.setOnLongClickListener(v -> beginDetail());
            final View pressTarget = shell;
            touch.setOnTouchListener((v, event) -> {
                switch (event.getAction()) {
                    case android.view.MotionEvent.ACTION_DOWN:
                        press(pressTarget, 0.96f);
                        break;
                    case android.view.MotionEvent.ACTION_UP:
                    case android.view.MotionEvent.ACTION_CANCEL:
                        release(pressTarget);
                        break;
                    default:
                        break;
                }
                return false;
            });
            shell.addView(touch, new FrameLayout.LayoutParams(-1, -1));
            if (iconView != null) {
                int box = dp(rows >= 2 ? 36 : 38);
                iconBox = new FrameLayout(getContext());
                this.iconBox = iconBox;
                iconBox.setClipChildren(false);
                iconBox.setClipToPadding(false);
                plate = new PlateView(spec);
                iconBox.addView(plate, new FrameLayout.LayoutParams(-1, -1));
                tintWhite(iconView);
                // The icon view has its own minimum size and gets clipped when
                // we shrink its layout box; scale the glyph instead.
                FrameLayout.LayoutParams iconParams = new FrameLayout.LayoutParams(-1, -1,
                    android.view.Gravity.CENTER);
                iconBox.addView(iconView, iconParams);
                try { Z1.call(iconView, "setIconScaleRatio", Float.valueOf(0.62f)); }
                catch (Throwable t) { Z1.log("detail icon scale failed: " + spec, t); }
                FrameLayout.LayoutParams boxParams = rows >= 2
                    ? new FrameLayout.LayoutParams(box, box, android.view.Gravity.TOP | android.view.Gravity.START)
                    : new FrameLayout.LayoutParams(box, box, android.view.Gravity.CENTER_VERTICAL | android.view.Gravity.START);
                boxParams.leftMargin = dp(rows >= 2 ? 14 : 10);
                if (rows >= 2) boxParams.topMargin = dp(14);
                shell.addView(iconBox, boxParams);
            }
            label = new TextView(getContext());
            label.setTextColor(Color.WHITE);
            label.setTextSize(16);
            label.setMaxLines(1);
            secondary = new TextView(getContext());
            secondary.setTextColor(0xB3FFFFFF);
            secondary.setTextSize(13);
            secondary.setVisibility(View.GONE);
            chevron = new ChevronView(getContext());
            chevron.setVisibility(View.GONE);
            LinearLayout box = new LinearLayout(getContext());
            box.setOrientation(LinearLayout.VERTICAL);
            box.addView(label, new LinearLayout.LayoutParams(-1, -2));
            LinearLayout sub = new LinearLayout(getContext());
            sub.setGravity(android.view.Gravity.CENTER_VERTICAL);
            sub.addView(secondary, new LinearLayout.LayoutParams(-2, -2));
            LinearLayout.LayoutParams chevronParams = new LinearLayout.LayoutParams(-2, -2);
            chevronParams.leftMargin = dp(4);
            sub.addView(chevron, chevronParams);
            box.addView(sub, new LinearLayout.LayoutParams(-1, -2));
            FrameLayout.LayoutParams boxParams = rows >= 2
                ? new FrameLayout.LayoutParams(-1, -2, android.view.Gravity.BOTTOM | android.view.Gravity.START)
                : new FrameLayout.LayoutParams(-1, -2, android.view.Gravity.CENTER_VERTICAL | android.view.Gravity.START);
            boxParams.leftMargin = dp(rows >= 2 ? 14 : 66);
            boxParams.rightMargin = dp(12);
            if (rows >= 2) boxParams.bottomMargin = dp(14);
            shell.addView(box, boxParams);
            return shell;
        }

        private void tintWhite(View view) {
            if (view == null) return;
            if (view instanceof android.widget.ImageView)
                ((android.widget.ImageView) view).setColorFilter(Color.WHITE, android.graphics.PorterDuff.Mode.SRC_IN);
            if (view instanceof ViewGroup) {
                ViewGroup group = (ViewGroup) view;
                for (int i = 0; i < group.getChildCount(); i++) tintWhite(group.getChildAt(i));
            }
        }

        /** The tile surface must never switch to its active highlight style:
         *  outside the QS panel that style is an opaque white sheet. */
        private Object neutral(Object state) {
            Object copy = state;
            try {
                copy = Z1.copyState(state);
                XposedHelpers.setObjectField(copy, "state", Integer.valueOf(1));
            } catch (Throwable ignored) { }
            return copy;
        }

        private View tileView(View shell) {
            if (shell instanceof ViewGroup && ((ViewGroup) shell).getChildCount() > 0)
                return ((ViewGroup) shell).getChildAt(0);
            return shell;
        }

        private void applyLabels(Object state) {
            if (state == null) return;
            Object text = Z1.fieldValue(state, "label");
            if (label != null && text != null) label.setText(String.valueOf(text));
            Object second = Z1.fieldValue(state, "secondaryLabel");
            String secondText = second == null ? "" : String.valueOf(second);
            if (secondary != null) {
                secondary.setText(secondText);
                secondary.setVisibility(secondText.isEmpty() ? View.GONE : View.VISIBLE);
            }
            boolean expandable = Boolean.TRUE.equals(Z1.fieldValue(state, "dualTarget"))
                || Boolean.TRUE.equals(Z1.fieldValue(state, "handlesSecondaryClick"));
            if (chevron != null) chevron.setVisibility(expandable ? View.VISIBLE : View.GONE);
            boolean on = Z1.numberField(state, "state") == 2;
            if (plate != null) plate.setActive(on);
            if (iconView != null) {
                // The tile posts its own state runnable, which re-applies the
                // neutral icon afterwards; repaint the real one a frame later.
                final Object iconState = state;
                Z1.MAIN.post(() -> applyIcon(iconState));
                Z1.MAIN.postDelayed(() -> applyIcon(iconState), 80);
            }
            if (highlight != null) highlight.setVisibility(on ? View.GONE : highlightVisibility);
        }

        private boolean beginDetail() {
            longPressed = DetailTile.this;
            if (handle != null) handle.detail(iconBox != null ? (View) iconBox : (View) view);
            return true;
        }

        private void press(View target, float scale) {
            if (target == null) return;
            target.animate().cancel();
            target.animate().scaleX(scale).scaleY(scale).setDuration(90)
                .setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
        }

        private void release(View target) {
            if (target == null) return;
            target.animate().cancel();
            target.animate().scaleX(1f).scaleY(1f).setDuration(220)
                .setInterpolator(new android.view.animation.OvershootInterpolator(1.4f)).start();
        }

        private void applyIcon(Object state) {
            if (closed || iconView == null) return;
            try { Z1.call(iconView, "setIcon", state, Boolean.TRUE); }
            catch (Throwable t) { Z1.log("detail icon state failed: " + spec, t); }
        }

        boolean available() { return view != null; }

        void close() {
            if (closed) return;
            closed = true;
            try { Z1.call(tileView(view), "onRecycle"); } catch (Throwable ignored) { }
            if (handle != null) handle.close();
        }
    }

    /** Small iOS style chevron.up.chevron.down glyph, drawn instead of using
     *  font characters (they render with a huge gap at these sizes). */
    final class ChevronView extends View {
        private final android.graphics.Paint paint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.Path path = new android.graphics.Path();

        ChevronView(android.content.Context context) {
            super(context);
            paint.setStyle(android.graphics.Paint.Style.STROKE);
            paint.setStrokeCap(android.graphics.Paint.Cap.ROUND);
            paint.setStrokeJoin(android.graphics.Paint.Join.ROUND);
            paint.setStrokeWidth(Math.max(2f, 1.6f * context.getResources().getDisplayMetrics().density));
            paint.setColor(0xB3FFFFFF);
        }

        @Override protected void onMeasure(int widthSpec, int heightSpec) {
            int width = dp(10);
            int height = dp(14);
            setMeasuredDimension(resolveSize(width, widthSpec), resolveSize(height, heightSpec));
        }

        @Override protected void onDraw(android.graphics.Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            float inset = w * 0.18f;
            float upTop = h * 0.04f, upBottom = h * 0.36f;
            float downTop = h * 0.64f, downBottom = h * 0.96f;
            path.reset();
            path.moveTo(inset, upBottom);
            path.lineTo(w / 2f, upTop);
            path.lineTo(w - inset, upBottom);
            path.moveTo(inset, downTop);
            path.lineTo(w / 2f, downBottom);
            path.lineTo(w - inset, downTop);
            canvas.drawPath(path, paint);
        }
    }

    /** Circular plate behind the native icon: outside the QS panel the tile
     *  only paints the glyph, so the plate is recreated here. */
    final class PlateView extends View {
        private final String spec;
        private final android.graphics.Paint paint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private boolean active;

        PlateView(String spec) { super(R1.this.getContext()); this.spec = spec; setWillNotDraw(false); }

        void setActive(boolean value) {
            if (active == value) return;
            active = value;
            invalidate();
        }

        int color() {
            int value = 0x26FFFFFF;
            if (active) {
                value = 0xFF3B82F6;
                if (spec != null) {
                    if (spec.equals("cell") || spec.equals("hotspot")) value = 0xFF22C55E;
                    else if (spec.equals("bt")) value = 0xFF6B7280;
                }
            }
            return value;
        }

        @Override protected void onDraw(android.graphics.Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth(), h = getHeight();
            if (w == 0 || h == 0) return;
            paint.setStyle(android.graphics.Paint.Style.FILL);
            paint.setColor(color());
            canvas.drawCircle(w / 2f, h / 2f, Math.min(w, h) / 2f, paint);
        }
    }

    /** Draws a circle-to-rounded-rectangle container transform. The glyph is
     * kept at roughly its original size and fades out instead of being scaled
     * with the whole plate bitmap. */
    final class MorphView extends View {
        private final android.graphics.Paint fill =
            new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.Paint glyphPaint =
            new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG
                | android.graphics.Paint.FILTER_BITMAP_FLAG);
        private final android.graphics.RectF shape = new android.graphics.RectF();
        private final android.graphics.RectF glyphDst = new android.graphics.RectF();
        private android.graphics.Rect fromRect;
        private android.graphics.Rect toRect;
        private float fromRadius;
        private float toRadius;
        private float progress;
        private int color = 0x26FFFFFF;
        private android.graphics.Bitmap glyph;
        private boolean fadeWithProgress;

        MorphView(android.content.Context context) { super(context); setWillNotDraw(false); }

        void begin(android.graphics.Rect from, float radius, int color, android.graphics.Bitmap glyph) {
            fromRect = new android.graphics.Rect(from);
            toRect = new android.graphics.Rect(from);
            fromRadius = radius;
            toRadius = radius;
            this.color = color;
            this.glyph = glyph;
            progress = 0f;
            invalidate();
        }

        void setTarget(android.graphics.Rect target, float radius) {
            if (target == null) return;
            toRect = new android.graphics.Rect(target);
            toRadius = radius;
            invalidate();
        }

        void setProgress(float value) {
            progress = Math.max(0f, Math.min(1f, value));
            invalidate();
        }

        /** When set, the surface starts almost invisible and firms up as it
         *  shrinks, instead of showing a big pale rectangle over the page. */
        void setFadeWithProgress(boolean value) { fadeWithProgress = value; }

        @Override protected void onDraw(android.graphics.Canvas canvas) {
            super.onDraw(canvas);
            if (fromRect == null || toRect == null) return;
            float p = progress;
            shape.set(fromRect.left + (toRect.left - fromRect.left) * p,
                fromRect.top + (toRect.top - fromRect.top) * p,
                fromRect.right + (toRect.right - fromRect.right) * p,
                fromRect.bottom + (toRect.bottom - fromRect.bottom) * p);
            float radius = fromRadius + (toRadius - fromRadius) * p;
            radius = Math.min(radius, Math.min(shape.width(), shape.height()) / 2f);
            fill.setStyle(android.graphics.Paint.Style.FILL);
            int paintColor = color;
            if (fadeWithProgress) {
                int baseAlpha = android.graphics.Color.alpha(color);
                int alpha = (int) (baseAlpha * (0.12f + 0.88f * p));
                paintColor = (color & 0x00FFFFFF) | (alpha << 24);
            }
            fill.setColor(paintColor);
            canvas.drawRoundRect(shape, radius, radius, fill);
            if (glyph != null && !glyph.isRecycled()) {
                float alpha = 1f - Math.min(1f, p * 2.4f);
                if (alpha > 0.02f) {
                    float scale = 1f;
                    float width = glyph.getWidth() * scale;
                    float height = glyph.getHeight() * scale;
                    glyphDst.set(shape.centerX() - width / 2f, shape.centerY() - height / 2f,
                        shape.centerX() + width / 2f, shape.centerY() + height / 2f);
                    glyphPaint.setAlpha((int) (alpha * 255f));
                    canvas.drawBitmap(glyph, null, glyphDst, glyphPaint);
                }
            }
        }
    }

    final class NativeItem {
        final String spec; final Z1.TileHandle handle; final View nativeView; final FrameLayout compactView; final TextView label;
        final TextView secondary; final TextView chevron;
        final java.util.concurrent.atomic.AtomicReference<View> adapterRef = new java.util.concurrent.atomic.AtomicReference<>();
        View detailTile;
        boolean closed;
        NativeItem(String spec, boolean withLabel) {
            this.spec = spec;
            this.handle = Z1.acquire(spec);
            this.label = new TextView(getContext());
            this.label.setGravity(android.view.Gravity.CENTER); this.label.setTextColor(Color.WHITE); this.label.setTextSize(12);
            this.secondary = new TextView(getContext());
            this.secondary.setTextColor(0xB3FFFFFF);
            this.secondary.setTextSize(14);
            this.secondary.setVisibility(View.GONE);
            this.chevron = new TextView(getContext());
            this.chevron.setText("\u2304");
            this.chevron.setTextColor(0xB3FFFFFF);
            this.chevron.setTextSize(14);
            this.chevron.setVisibility(View.GONE);
            FrameLayout frame = new FrameLayout(getContext()); this.compactView = frame; frame.setTag(this); frame.setClipChildren(false); frame.setClipToPadding(false);
            View view = null;
            if (handle != null) {
                try { view = createNativeView(handle.tile()); } catch (Throwable t) { Z1.log("native child view failed: " + spec, t); }
            }
            this.nativeView = view == null ? new View(getContext()) : view;
            FrameLayout.LayoutParams childParams = new FrameLayout.LayoutParams(-1, -1);
            childParams.gravity = android.view.Gravity.CENTER;
            frame.addView(this.nativeView, childParams);
            this.nativeView.setClickable(false); this.nativeView.setFocusable(false);
            if (handle != null) {
                try { handle.start(state -> applyState(state)); } catch (Throwable t) { Z1.log("native state callback failed: " + spec, t); }
            }
        }
        boolean available() { return handle != null && nativeView != null; }
        void setIconFactor(float factor) { if (nativeView instanceof BareIconView) ((BareIconView) nativeView).setIconFactor(factor); }
        View createNativeView(Object tile) throws Throwable {
            // Keep a native OneXOne only as a state adapter. The visible child is
            // a bare icon with its own circle; no child QS surface is rendered.
            Class<?> one = Z1.find("com.oplus.systemui.plugins.qs.customize.view.tile.OplusQSResizeableTileViewOneXOne");
            Class<?> iconType = Z1.find("com.oplus.systemui.plugins.qs.customize.view.tile.OplusQSIconView");
            Class<?> labelType = Z1.find("com.oplus.systemui.plugins.qs.customize.view.tile.QsLabelView");
            Object icon = XposedHelpers.newInstance(iconType, getContext(), Z1.span(1, 1), Boolean.FALSE);
            Object qsLabel = XposedHelpers.newInstance(labelType, getContext());
            try { Z1.call(qsLabel, "setEnableExpandIndicator", Boolean.FALSE); } catch (Throwable ignored) { }
            Object adapter = XposedHelpers.newInstance(one, getContext(), icon, qsLabel);
            Z1.call(adapter, "init", tile);
            adapterRef.set((View) adapter);
            try { Z1.call(qsLabel, "setVisibility", View.GONE); } catch (Throwable ignored) { }
            try {
                Object bg = Z1.call(adapter, "getBg");
                if (bg instanceof View) ((View) bg).setVisibility(View.GONE);
            } catch (Throwable ignored) { }
            try { Z1.prepareNativeChild((View) adapter); } catch (Throwable ignored) { }
            try { Z1.call(adapter, "setStateImmediately", Z1.copyState(Z1.call(tile, "getState"))); } catch (Throwable ignored) { }
            BareIconView bare = new BareIconView(spec, (View) adapter);
            bare.accept(Z1.copyState(Z1.call(tile, "getState")));
            return bare;
        }
        void applyState(Object state) {
            if (closed || state == null) return;
            Z1.MAIN.post(() -> {
                if (closed) return;
                if (nativeView instanceof BareIconView) ((BareIconView) nativeView).accept(state);
                Object adapter = adapterRef.get();
                if (adapter != null) {
                    try { Object bg = Z1.call(adapter, "getBg"); if (bg instanceof View) ((View) bg).setVisibility(View.GONE); } catch (Throwable ignored) { }
                    try { Z1.call(adapter, "onStateChanged", state); } catch (Throwable ignored) { }
                }
                if (detailTile != null) {
                    try { Z1.call(detailTile, "setState", state); Z1.call(detailTile, "onStateChanged", state); } catch (Throwable ignored) { }
                }
                Object text = Z1.fieldValue(state, "label"); if (text != null) label.setText(String.valueOf(text));
                Object second = Z1.fieldValue(state, "secondaryLabel");
                String secondText = second == null ? "" : String.valueOf(second);
                secondary.setText(secondText);
                secondary.setVisibility(secondText.length() == 0 ? View.GONE : View.VISIBLE);
                boolean expandable = Boolean.TRUE.equals(Z1.fieldValue(state, "dualTarget"))
                    || Boolean.TRUE.equals(Z1.fieldValue(state, "handlesSecondaryClick"));
                chevron.setVisibility(expandable ? View.VISIBLE : View.GONE);
                compactView.setContentDescription(text == null ? spec : String.valueOf(text));
            });
        }
        void close() {
            if (closed) return;
            closed = true;
            View adapter = adapterRef.get();
            if (adapter != null) { try { Z1.call(adapter, "onRecycle"); } catch (Throwable ignored) { } adapterRef.set(null); }
            if (handle != null) handle.close();
        }
    }
}
