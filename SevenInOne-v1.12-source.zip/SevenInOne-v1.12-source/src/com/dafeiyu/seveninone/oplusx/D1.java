package com.dafeiyu.seveninone.oplusx;

import java.util.Arrays;
import org.json.JSONArray;
import org.json.JSONObject;

/** The OplusX combo configuration model, retained for compatible JSON shape. */
public final class D1 {
    public static final String SPEC = "dafeiyu_combo_2x2";
    public static final String LABEL = "七合一";
    public final int count;
    public final String[] specs = new String[7];

    public D1(int count, String[] input) {
        this.count = Math.max(3, Math.min(7, count));
        for (int i = 0; i < 7; i++) {
            String value = input != null && i < input.length ? input[i] : "";
            this.specs[i] = valid(value) ? value : "";
        }
    }

    public static D1 empty() { return new D1(4, new String[0]); }

    public static boolean valid(String value) {
        return value != null && value.length() > 0 && value.length() <= 512
            && !value.startsWith("oplusx_combo_") && !value.startsWith("dafeiyu_combo_")
            && (value.matches("[A-Za-z0-9_.:-]+")
                || value.matches("custom\\([A-Za-z0-9_.$]+/[A-Za-z0-9_.$]+\\)"));
    }

    public static D1 fromJson(String value) {
        try {
            JSONObject object = new JSONObject(value);
            if (object.optInt("version", 0) != 1) return empty();
            JSONArray array = object.optJSONArray("specs");
            String[] result = new String[7];
            for (int i = 0; i < 7; i++) result[i] = array == null ? "" : array.optString(i, "");
            return new D1(object.optInt("count", 4), result);
        } catch (Throwable ignored) { return empty(); }
    }

    public String toJson() {
        try {
            JSONArray array = new JSONArray();
            for (String spec : specs) array.put(spec);
            return new JSONObject().put("version", 1).put("count", count)
                .put("specs", array).toString();
        } catch (Throwable e) { return "{}"; }
    }

    /** OplusX layout rule: with more than four entries slot 3 is the group. */
    public boolean isGroupSlot(int slot) { return count > 4 && slot == 3; }

    public int[] childrenForSlot(int slot) {
        if (slot < 0 || slot >= Math.min(4, count)) return new int[0];
        if (!isGroupSlot(slot)) return new int[] {slot};
        int[] result = new int[count - 3];
        for (int i = 0; i < result.length; i++) result[i] = i + 3;
        return result;
    }

    public D1 swapped(int first, int second) {
        if (first < 0 || second < 0 || first >= count || second >= count || first == second)
            throw new IndexOutOfBoundsException("slot");
        String[] result = specs.clone();
        String temp = result[first]; result[first] = result[second]; result[second] = temp;
        return new D1(count, result);
    }

    @Override public boolean equals(Object other) {
        return other instanceof D1 && count == ((D1) other).count
            && Arrays.equals(specs, ((D1) other).specs);
    }
    @Override public int hashCode() { return 31 * count + Arrays.hashCode(specs); }
}
