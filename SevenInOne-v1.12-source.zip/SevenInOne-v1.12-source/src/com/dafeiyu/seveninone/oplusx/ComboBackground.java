package com.dafeiyu.seveninone.oplusx;

import android.graphics.drawable.Drawable;
import android.util.StateSet;
import android.view.View;
import de.robv.android.xposed.XposedHelpers;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

/**
 * Port of OplusX's C0602m8 inactive neutral tile surface. This is a plain
 * drawable background, not a QSTile view, so it cannot be picked up as a
 * separate liquid-glass tile. Active children keep the native tile background.
 */
final class ComboBackground {
    private static final Map<View, Object[]> CACHE = new WeakHashMap<>();
    private static final Map<View, Object[]> RADIUS_CACHE = new WeakHashMap<>();
    private static final Set<View> LOGGED = java.util.Collections.newSetFromMap(new java.util.IdentityHashMap<View, Boolean>());

    private ComboBackground() {}

    static void apply(View view, ClassLoader loader) {
        try {
            Drawable drawable = build(view, loader, outline(loader), false);
            if (view.getBackground() != drawable) view.setBackground(drawable);
        } catch (Throwable t) {
            Z1.log("neutral background unavailable", t);
        }
    }

    static Drawable build(View view, ClassLoader loader, Object outline, boolean active) throws Throwable {
        int color = inactiveColor(view, loader);
        Object[] cached = CACHE.get(view);
        if (cached != null && ((Integer) cached[0]).intValue() == color && cached[1] == outline
                && ((Boolean) cached[2]).booleanValue() == active) {
            return (Drawable) cached[3];
        }
        LinkedHashMap<Object, Object> states = new LinkedHashMap<>();
        Class<?> drawableState = XposedHelpers.findClass("com.oplus.systemui.qs.base.res.model.DrawableState", loader);
        if (active) {
            Class<?> flag = XposedHelpers.findClass("com.oplus.systemui.qs.base.res.model.TileViewFlag", loader);
            Object activeFlag = XposedHelpers.getStaticObjectField(flag, "Active");
            states.put(XposedHelpers.newInstance(drawableState, XposedHelpers.callMethod(activeFlag, "getFlag")), Integer.valueOf(0));
        }
        states.put(XposedHelpers.newInstance(drawableState, new int[0]), Integer.valueOf(color));
        Class<?> builderType = XposedHelpers.findClass("com.oplus.systemui.qs.base.res.drawable.GradientTileDrawable$Builder", loader);
        Object builder = XposedHelpers.newInstance(builderType, states);
        Drawable drawable = (Drawable) XposedHelpers.callMethod(builder, "build", view, Boolean.FALSE, null);
        if (outline != null) XposedHelpers.callMethod(drawable, "setPathProvider", outline);
        CACHE.put(view, new Object[] {Integer.valueOf(color), outline, Boolean.valueOf(active), drawable});
        return drawable;
    }

    private static int inactiveColor(View view, ClassLoader loader) throws Throwable {
        Object builder = XposedHelpers.callMethod(XposedHelpers.callMethod(
            XposedHelpers.getStaticObjectField(XposedHelpers.findClass("com.oplus.systemui.qs.base.res.SepQSResPool", loader), "INSTANCE"),
            "getTileViewDrawable"), "getValue");
        if (builder != null && builder.getClass().getName().endsWith("GradientTileDrawable$Builder")) {
            Class<?> flagType = XposedHelpers.findClass("com.oplus.systemui.qs.base.res.model.TileViewFlag", loader);
            int[] inactive = (int[]) XposedHelpers.callMethod(XposedHelpers.getStaticObjectField(flagType, "Inactive"), "getFlag");
            Object colors = XposedHelpers.getObjectField(builder, "stateListColors");
            if (colors instanceof Map) {
                for (Object entryObject : ((Map<?, ?>) colors).entrySet()) {
                    Map.Entry<?, ?> entry = (Map.Entry<?, ?>) entryObject;
                    Object state = entry.getKey();
                    Object spec = XposedHelpers.getObjectField(state, "stateSpec");
                    if (spec instanceof int[] && StateSet.stateSetMatches((int[]) spec, inactive)) {
                        return ((Number) entry.getValue()).intValue();
                    }
                }
            }
        }
        String field = (view.getResources().getConfiguration().uiMode & 48) == 32
            ? "QS_INACTIVE_NIGHT_BG_COLOR" : "QS_INACTIVE_LIGHT_BG_COLOR";
        return ((Number) XposedHelpers.getStaticObjectField(
            XposedHelpers.findClass("com.oplusos.systemui.common.util.QSBlurConfigProvider", loader), field)).intValue();
    }

    /** Same native surface, but with the large panel outline so 2x1 pills and
     *  2x2 squares keep their system corner radius instead of a circle. */
    static void applyLarge(View view, ClassLoader loader) {
        try {
            Drawable drawable = build(view, loader, mediaOutline(loader), false);
            if (view.getBackground() != drawable) view.setBackground(drawable);
        } catch (Throwable t) {
            Z1.log("large neutral background unavailable", t);
        }
    }

    private static Object mediaOutline(ClassLoader loader) throws Throwable {
        return XposedHelpers.callMethod(XposedHelpers.callMethod(
            XposedHelpers.getStaticObjectField(XposedHelpers.findClass("com.oplus.systemui.qs.base.res.SepQSResPool", loader), "INSTANCE"),
            "getMediaPanelOutline"), "getValue");
    }

    private static Object outline(ClassLoader loader) throws Throwable {
        return XposedHelpers.callMethod(XposedHelpers.callMethod(
            XposedHelpers.getStaticObjectField(XposedHelpers.findClass("com.oplus.systemui.qs.base.res.SepQSResPool", loader), "INSTANCE"),
            "getTileOutline"), "getValue");
    }
}
