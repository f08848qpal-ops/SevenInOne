package com.dafeiyu.seveninone.oplusx;

import android.os.Handler;
import android.os.Looper;
import android.view.View;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import java.util.ArrayList;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * OplusX's large-panel outline bridge. The outer 2x2 background keeps the
 * native liquid-glass drawable, but its block path is changed to the same
 * media/large-panel outline used by the music card.
 */
final class B8 {
    private static final String KEY = "seveninone_large_panel_outline";
    private static final Map<View, State> ACTIVE = new WeakHashMap<>();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static ClassLoader loader;
    private static boolean installed;

    private static final class State {
        Object originalProvider;
        Object drawable;
        boolean logged;
    }

    private B8() {}

    static synchronized void install(ClassLoader classLoader) {
        if (installed) return;
        loader = classLoader;
        try {
            Class<?> two = XposedHelpers.findClass(
                "com.oplus.systemui.plugins.qs.customize.view.tile.OplusQSResizeableTileViewTwoXTwo", classLoader);
            XC_MethodHook sync = new XC_MethodHook() {
                @Override protected void afterHookedMethod(XC_MethodHook.MethodHookParam p) {
                    if (!p.hasThrowable()) {
                        try { sync((View) p.thisObject); } catch (Throwable t) { Z1.log("large outline sync failed", t); }
                    }
                }
            };
            XposedBridge.hookAllMethods(two, "onOutlineUpdate", sync);
            XposedBridge.hookAllMethods(two, "onDrawableUpdate", sync);
            for (String name : new String[] {"getCornerRadius", "getCornerWeight"}) {
                final String method = name;
                XposedBridge.hookAllMethods(two, name, new XC_MethodHook() {
                    @Override protected void afterHookedMethod(XC_MethodHook.MethodHookParam p) {
                        State state = state((View) p.thisObject);
                        if (state == null || state.drawable == null) return;
                        try {
                            Object provider = XposedHelpers.callMethod(state.drawable, "getPathProvider");
                            p.setResult(XposedHelpers.callMethod(provider, method, state.drawable));
                        } catch (Throwable ignored) { }
                    }
                });
            }
            XposedBridge.hookAllMethods(two.getSuperclass(), "onRecycle", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(XC_MethodHook.MethodHookParam p) {
                    try { release((View) p.thisObject); } catch (Throwable ignored) { }
                }
            });
            Class<?> pool = XposedHelpers.findClass("com.oplus.systemui.qs.base.res.SepQSResPool", classLoader);
            XposedBridge.hookAllMethods(pool, "updateMediaPanelOutline", new XC_MethodHook() {
                @Override protected void afterHookedMethod(XC_MethodHook.MethodHookParam p) {
                    MAIN.post(() -> {
                        for (View view : new ArrayList<View>(ACTIVE.keySet())) {
                            try { sync(view); } catch (Throwable ignored) { }
                        }
                    });
                }
            });
            installed = true;
        } catch (Throwable t) {
            Z1.log("large-panel outline hooks unavailable", t);
        }
    }

    static void e(View view, ClassLoader classLoader) {
        if (view == null) return;
        install(classLoader);
        synchronized (ACTIVE) {
            if (state(view) == null) XposedHelpers.setAdditionalInstanceField(view, KEY, new State());
            ACTIVE.put(view, state(view));
        }
        sync(view);
    }

    static void f(View view) {
        if (view == null) return;
        release(view);
    }

    private static void release(View view) {
        State state = state(view);
        synchronized (ACTIVE) { ACTIVE.remove(view); }
        XposedHelpers.setAdditionalInstanceField(view, KEY, null);
        if (state == null || state.drawable == null) return;
        try { XposedHelpers.callMethod(state.drawable, "setBlockPathProvider", state.originalProvider); }
        catch (Throwable ignored) { }
    }

    private static State state(View view) {
        try { return (State) XposedHelpers.getAdditionalInstanceField(view, KEY); }
        catch (Throwable ignored) { return null; }
    }

    private static Object outline() throws Throwable {
        Object pool = XposedHelpers.getStaticObjectField(
            XposedHelpers.findClass("com.oplus.systemui.qs.base.res.SepQSResPool", loader), "INSTANCE");
        return XposedHelpers.callMethod(XposedHelpers.callMethod(pool, "getMediaPanelOutline"), "getValue");
    }

    private static void sync(View view) {
        State state = state(view);
        if (state == null) return;
        try {
            Object largeOutline = outline();
            if (largeOutline == null || !largeOutline.getClass().getName().endsWith(".RoundRectOutlineProvider")) return;
            Object transition = XposedHelpers.callMethod(view, "getTransitionDrawable");
            if (transition == null) return;
            if (state.drawable != transition) {
                if (state.drawable != null && state.originalProvider != null) {
                    try { XposedHelpers.callMethod(state.drawable, "setBlockPathProvider", state.originalProvider); }
                    catch (Throwable ignored) { }
                }
                state.drawable = transition;
                Object delegate = XposedHelpers.getObjectField(transition, "delegate");
                state.originalProvider = XposedHelpers.getObjectField(delegate, "blockPathProvider");
            }
            XposedHelpers.callMethod(transition, "setBlockPathProvider", largeOutline);
            if (!state.logged) {
                state.logged = true;
                Z1.log("outer 2x2 uses native media-panel outline");
            }
        } catch (Throwable t) {
            Z1.log("outer outline apply failed: " + t);
        }
    }
}
