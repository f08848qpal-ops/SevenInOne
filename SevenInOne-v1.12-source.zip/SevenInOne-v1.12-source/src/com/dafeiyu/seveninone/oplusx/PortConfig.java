package com.dafeiyu.seveninone.oplusx;

import android.content.ContentResolver;
import android.content.Context;
import android.util.Log;
import android.net.Uri;
import android.os.Bundle;
import com.dafeiyu.seveninone.SevenProvider;
import com.dafeiyu.seveninone.TileCatalog;
import java.util.Arrays;

/** SystemUI-side adapter for the app-owned, configuration-only provider. */
final class PortConfig {
    private static final Uri URI = SevenProvider.URI;
    private PortConfig() {}

    private static final String GLOBAL_KEY = "dafeiyu_seveninone_config_v1";

    /**
     * Provider is the source of truth, but a restarted SystemUI can arrive
     * before the app provider is registered (or while the package is stopped).
     * Keep a SystemUI-readable Settings.Global cache after every successful
     * provider read so a reboot never falls back to defaults.
     */
    static D1 read(Context context) {
        D1 provider = readProvider(context);
        if (provider != null) {
            writeGlobal(context, provider);
            Log.i("SevenInOne", "config source=provider " + provider.toJson());
            return provider;
        }
        D1 cached = readGlobal(context);
        if (cached != null) {
            Log.i("SevenInOne", "config source=global " + cached.toJson());
            return cached;
        }
        D1 fallback = new D1(7, TileCatalog.DEFAULT.clone());
        Log.w("SevenInOne", "config source=default (provider and global cache unavailable)");
        return fallback;
    }

    private static D1 readProvider(Context context) {
        try {
            Bundle b = context.getContentResolver().call(URI, "config", null, null);
            String[] selected = b == null ? null : b.getStringArray("selected");
            if (selected != null && selected.length >= 3 && selected.length <= 7) {
                return new D1(selected.length, selected);
            }
        } catch (Throwable t) { Log.e("SevenInOne", "provider read failed", t); }
        return null;
    }

    private static D1 readGlobal(Context context) {
        try {
            String joined = globalGet(context);
            if (joined == null || joined.isEmpty()) return null;
            String[] raw = joined.split(",", -1);
            java.util.ArrayList<String> values = new java.util.ArrayList<>();
            for (String value : raw) {
                if (D1.valid(value) && !values.contains(value)) values.add(value);
            }
            if (values.size() >= 3 && values.size() <= 7) {
                return new D1(values.size(), values.toArray(new String[0]));
            }
        } catch (Throwable t) { Log.e("SevenInOne", "global config read failed", t); }
        return null;
    }

    static void cache(Context context, D1 config) { writeGlobal(context, config); }

    private static void writeGlobal(Context context, D1 config) {
        try {
            StringBuilder joined = new StringBuilder();
            for (int i = 0; i < config.count; i++) {
                if (joined.length() > 0) joined.append(',');
                joined.append(config.specs[i]);
            }
            Class<?> global = Class.forName("android.provider.Settings$Global");
            global.getMethod("putString", android.content.ContentResolver.class, String.class, String.class)
                .invoke(null, context.getContentResolver(), GLOBAL_KEY, joined.toString());
        } catch (Throwable t) { Log.w("SevenInOne", "global config cache write failed", t); }
    }

    private static String globalGet(Context context) throws Throwable {
        Class<?> global = Class.forName("android.provider.Settings$Global");
        Object value = global.getMethod("getString", android.content.ContentResolver.class, String.class)
            .invoke(null, context.getContentResolver(), GLOBAL_KEY);
        return value instanceof String ? (String) value : null;
    }

    static boolean enabled(Context context) {
        try {
            Bundle b = context.getContentResolver().call(URI, "config", null, null);
            return b != null && b.getBoolean("enabled", true);
        } catch (Throwable t) {
            Log.e("SevenInOne", "provider enabled failed", t);
            return true;
        }
    }

    static boolean showLabels(Context context) {
        try {
            Bundle b = context.getContentResolver().call(URI, "config", null, null);
            return b != null && b.getBoolean("show_labels", false);
        } catch (Throwable t) {
            Log.e("SevenInOne", "provider labels failed", t);
            return false;
        }
    }

    static boolean longPressExpand(Context context) {
        try {
            Bundle b = context.getContentResolver().call(URI, "config", null, null);
            return b == null || b.getBoolean("long_press_expand", true);
        } catch (Throwable ignored) {
            return true;
        }
    }

    static boolean save(Context context, D1 config) {
        if (config == null || config.count < 3 || config.count > 7) return false;
        try {
            String[] selected = Arrays.copyOf(config.specs, config.count);
            Bundle extras = new Bundle();
            extras.putStringArray("selected", selected);
            Bundle result = context.getContentResolver().call(URI, "save_systemui_config", null, extras);
            return result != null && result.getBoolean("ok", false);
        } catch (Throwable t) {
            Log.e("SevenInOne", "provider save failed", t);
            return false;
        }
    }
}
