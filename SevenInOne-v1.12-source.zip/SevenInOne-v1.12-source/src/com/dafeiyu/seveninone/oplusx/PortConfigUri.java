package com.dafeiyu.seveninone.oplusx;

import android.net.Uri;
import com.dafeiyu.seveninone.SevenProvider;

final class PortConfigUri {
    private PortConfigUri() {}
    static Uri uri() { return SevenProvider.URI; }
}
