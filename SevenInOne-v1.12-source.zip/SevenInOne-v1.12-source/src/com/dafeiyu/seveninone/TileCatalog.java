package com.dafeiyu.seveninone;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Configuration-side catalogue. The values are real SystemUI tile specs; the
 * SystemUI hook resolves them through QSHost and never executes them here.
 */
public final class TileCatalog {
    public static final String AIRPLANE = "airplane";
    public static final String OSHARE = "oshare";
    public static final String WIFI = "wifi";
    public static final String DATA = "cell";
    public static final String BLUETOOTH = "bt";
    public static final String LOCATION = "location";
    public static final String HOTSPOT = "hotspot";
    public static final String BATTERY = "battery";
    public static final String DND = "dnd";
    public static final String DARK = "darkmode";
    public static final String ROTATION = "rotation";
    public static final String NFC = "nfc";
    public static final String DUST_CLEAN = "custom(com.coloros.phonemanager/com.oplus.phonemanager.dustclean.DustCleanTileService)";
    public static final String BYPASS_CHARGE = "custom(com.luckyzyx.luckytool/.service.tiles.BypassPowerModeTile)";
    public static final String EXTRA_DIM = "custom(com.luckyzyx.luckytool/.service.tiles.ExtraDimModeTile)";
    public static final String VPN = "custom(app.getlux.com.sakuracat.app/.VpnTileService)";
    /** ColorOS power saving tile (this ROM has no plain "powersave" spec). */
    public static final String POWERSAVE = "custom(com.oplus.battery/com.oplus.powermanager.powersave.PowerSaveTileService)";

    public static final String[] IDS = {
        AIRPLANE, OSHARE, WIFI, DATA, BLUETOOTH, LOCATION, HOTSPOT,
        BATTERY, DND, DARK, ROTATION, NFC, DUST_CLEAN, BYPASS_CHARGE,
        EXTRA_DIM, VPN, POWERSAVE
    };
    public static final String[] NAMES = {
        "飞行模式", "一加互传", "WLAN", "移动数据", "蓝牙", "定位服务", "个人热点",
        "电池", "勿扰模式", "深色模式", "自动旋转", "NFC", "清灰排水",
        "旁路供电", "极暗模式", "SakuraCat", "省电模式"
    };
    public static final String[] SYMBOLS = {
        "✈", "◎", "⌁", "▮", "ᛒ", "➤", "↗", "▰", "◐", "☾", "⟳", "N", "✦", "⚡", "◌", "◇", "◉"
    };

    /** Public build default: the common system tiles every device exposes. */
    public static final String[] DEFAULT = {
        WIFI, HOTSPOT, DATA, LOCATION, AIRPLANE, DND, POWERSAVE
    };
    public static final List<String> DETAIL_WIDE = Collections.unmodifiableList(
        Arrays.asList(AIRPLANE, LOCATION, HOTSPOT));

    /** Chinese names for specs reported by the ROM that are not in IDS. */
    private static final java.util.HashMap<String, String> EXTRA = new java.util.HashMap<>();
    /** Full custom(...) specs -> readable Chinese name. */
    private static final java.util.HashMap<String, String> CUSTOM = new java.util.HashMap<>();

    static {
        EXTRA.put("ringermode", "响铃模式");
        EXTRA.put("flashlight", "手电筒");
        EXTRA.put("vibration", "振动");
        EXTRA.put("controls", "设备控制");
        EXTRA.put("wallet", "钱包");
        EXTRA.put("screenshot", "截屏");
        EXTRA.put("screenrecord", "屏幕录制");
        EXTRA.put("calculator", "计算器");
        EXTRA.put("clear", "一键清理");
        EXTRA.put("lockscreen", "锁屏");
        EXTRA.put("sync", "同步");
        EXTRA.put("reading", "阅读模式");
        EXTRA.put("eyedprotection", "护眼模式");
        EXTRA.put("screenrefresh", "屏幕刷新率");
        EXTRA.put("game", "游戏模式");
        EXTRA.put("headset", "耳机");
        EXTRA.put("alarm", "闹钟");
        EXTRA.put("cast", "投屏");
        EXTRA.put("nearby", "设备互联");
        EXTRA.put("nodisturb", "勿扰模式");
        EXTRA.put("superpowersave", "超级省电");
        EXTRA.put("battery", "电池");
        EXTRA.put("saver", "流量节省");
        EXTRA.put("nightmode", "夜间模式");
        EXTRA.put("hotspot", "个人热点");
        EXTRA.put("airplane", "飞行模式");
        EXTRA.put("location", "定位服务");
        EXTRA.put("darkmode", "深色模式");
        EXTRA.put("rotation", "自动旋转");
        EXTRA.put("inputmethod", "输入法");
        EXTRA.put("nfc", "NFC");
        EXTRA.put("wifi", "WLAN");
        EXTRA.put("cell", "移动数据");
        EXTRA.put("bt", "蓝牙");
        EXTRA.put("dnd", "免打扰");
        EXTRA.put("oshare", "一加互传");
        EXTRA.put("powersave", "省电模式");

        CUSTOM.put("custom(com.oplus.battery/com.oplus.powermanager.powersave.PowerSaveTileService)", "省电模式");
        CUSTOM.put("custom(com.coloros.oshare/com.oplus.oshare.OshareTileService)", "一加互传");
        CUSTOM.put("custom(com.oplus.eyeprotect/.services.EyeProtectTileService)", "护眼模式");
        CUSTOM.put("custom(com.oplus.linker/.synergy.service.TVTileService)", "设备互联");
        CUSTOM.put("custom(com.microsoft.appmanager/.quicksettings.WindowsLinkTileService)", "连接至 Windows");
        CUSTOM.put("custom(com.coloros.phonemanager/com.oplus.phonemanager.dustclean.DustCleanTileService)", "清灰排水");
        CUSTOM.put("custom(com.luckyzyx.luckytool/.service.tiles.BypassPowerModeTile)", "旁路供电");
        CUSTOM.put("custom(com.luckyzyx.luckytool/.service.tiles.ExtraDimModeTile)", "极暗模式");
        CUSTOM.put("custom(app.getlux.com.sakuracat.app/.VpnTileService)", "SakuraCat");
    }

    /** Chinese name for any spec, or null when this build has no translation. */
    public static String localized(String spec) {
        if (spec == null) return null;
        int index = indexOf(spec);
        if (index >= 0) return NAMES[index];
        String extra = EXTRA.get(spec);
        if (extra != null) return extra;
        return CUSTOM.get(spec);
    }

    private TileCatalog() {}

    public static int indexOf(String id) {
        if (id == null) return -1;
        for (int i = 0; i < IDS.length; i++) if (IDS[i].equals(id)) return i;
        return -1;
    }
    public static String label(String id) {
        int i = indexOf(id);
        return i < 0 ? id : NAMES[i];
    }
    public static String symbol(String id) {
        int i = indexOf(id);
        return i < 0 ? "•" : SYMBOLS[i];
    }
    public static boolean isDetailWide(String id) { return DETAIL_WIDE.contains(id); }
}
